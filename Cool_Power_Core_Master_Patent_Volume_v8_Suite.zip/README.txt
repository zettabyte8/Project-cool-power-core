COOL POWER CORE (CPC) - MASTER PATENT PORTFOLIO VOLUME v8 (73 CLAIMS | 25 FIGURES)
Inventor & Applicant: Thomas Gabriel Coleman (Corona, California, USA)
Master Priority Chain: CPC-PAT-2026-001 through CPC-PAT-2026-012-CIP + CPC-PCT-2026-001-WO
Date: November 27, 2026

CONTENTS:
1. Cool_Power_Core_Master_Patent_Volume_v8.pdf       - Print-ready landscape volume (73 claims, priority tree, 12-filing schedule)
2. Cool_Power_Core_ePCT_Full_Application_v8.xml      - WIPO ST.36 v1.9 validated XML filing (Biblio, Desc, 73 Rule 6.2(b) Claims, Rule 8 Abstract)
3. Cool_Power_Core_Master_Patent_v8_73Claims.xlsx    - Filterable Excel docket, 73-claim concordance, and portfolio audit
4. Cool_Power_Core_Master_Patent_Volume_v8.md        - Clean Markdown master reference
