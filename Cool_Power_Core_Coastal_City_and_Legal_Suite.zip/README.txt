COOL POWER CORE (CPC) - MUNICIPAL GROUND-LEASE & COASTAL SANCTUARY CITY SUITE
Inventor & Principal Architect: Thomas Gabriel Coleman (Corona, CA)
================================================================================
1. Cool_Power_Core_City_Resolution_and_Ground_Lease.docx : Model City Council Resolution & 99-Yr $1/yr Surplus Land Lease
2. Cool_Power_Core_Coastal_City_and_Legal_Spec.pdf        : Print-ready Coastal Hurricane-Resilient City & P3 Legal Spec
3. Cool_Power_Core_Coastal_City_and_Legal_Roadmap.xlsx    : Coastal Desalination/Energy Balance & 90-Day Entitlement Workbook
4. Cool_Power_Core_Coastal_City_and_Legal_Roadmap.md      : Editable Markdown Technical & Legal Reference
