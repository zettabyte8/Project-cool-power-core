COOL POWER CORE (CPC) — VOLUME VII (#301-#350) & UN/WORLD BANK GRANT SUITE
Inventor: Thomas Gabriel Coleman
Date: November 2026

Included Files:
1. Cool_Power_Core_Vol7_and_Humanitarian_Brief.pdf  - Print-ready Volume VII catalog & UN/World Bank grant brief
2. Cool_Power_Core_Vol7_and_Humanitarian_Brief.xlsx - Filterable 50-case database (#301-#350) & grant unit economics
3. Cool_Power_Core_Vol7_and_Humanitarian_Brief.md   - Editable Markdown master document
