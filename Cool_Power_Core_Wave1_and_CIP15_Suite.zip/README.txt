COOL POWER CORE (CPC) — WAVE 1 FRONTIER CATALOG (#1,863 - #2,012) & USPTO CIP-15
Inventor: Thomas Gabriel Coleman (Corona, CA)

Contents:
1. Cool_Power_Core_Wave1_and_CIP15.pdf         - Print-ready Wave 1 summary & USPTO FIGS. 29-30 drawings
2. Cool_Power_Core_Wave1_and_CIP15.xlsx        - 150-case Wave 1 database & Master 89-Claim Docket
3. Cool_Power_Core_Wave1_Catalog_and_CIP15.md  - Full Markdown specification & Claims 84-89
4. Cool_Power_Core_ePCT_Claims_84_to_89_v11.xml - WIPO ST.36 XML claim append file (Claims 84-89)
