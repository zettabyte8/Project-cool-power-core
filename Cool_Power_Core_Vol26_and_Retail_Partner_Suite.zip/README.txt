COOL POWER CORE (CPC) — VOLUME XXVI (#1,251-#1,300) & RETAIL/TINY-HOME OEM PARTNER SUITE
Inventor & IP Holder: Thomas Gabriel Coleman
Master Docket: CPC-PAT-2026-001-MASTER (31 Claims | 11 Figures)

Included Files:
1. Cool_Power_Core_Vol26_and_Retail_Partner.pdf  - Print-ready Volume XXVI catalog (#1,251-#1,300)
2. Cool_Power_Core_Vol26_and_Retail_Partner.xlsx - 3-tab Excel workbook (Vol. XXVI, 1,300-Case Rollup, Partner Specs)
3. Cool_Power_Core_Vol26_and_Retail_Partner.md   - Editable Markdown technical & commercial specification
4. Cool_Power_Core_Retail_OEM_Pitch_Deck.pptx    - 5-slide Retail Distributor & Tiny-Home OEM Partner Pitch Deck
