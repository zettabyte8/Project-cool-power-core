COOL POWER CORE (CPC) — MASTER PATENT PORTFOLIO VOLUME v4 & UPDATED OATH PACKET
Sole Inventor: Thomas Gabriel Coleman (Corona, California, USA)
Master Docket: CPC-PAT-2026-001-MASTER-V4
Date: November 26, 2026

INCLUDED FILES:
1. Cool_Power_Core_Master_Patent_Volume_v4_and_Oath.pdf  -> Consolidated Master Patent Volume v4 (Claims 1-43 | FIGS. 1-15) + Executed Forms PTO/AIA/01 & PTO/SB/15A
2. Cool_Power_Core_Master_Patent_Volume_v4.xlsx          -> Structured 3-Tab Docket, 15-Figure Concordance & USPTO Form Tracker
3. Cool_Power_Core_Master_Patent_Volume_v4_and_Oath.md   -> Editable Markdown Master Specification, All 43 Claims Summary & USPTO Declaration Templates
4. README.txt                                            -> Package Index
