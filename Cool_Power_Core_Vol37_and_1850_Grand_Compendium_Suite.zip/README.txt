COOL POWER CORE (CPC) - VOLUME XXXVII & 1,850-APPLICATION GRAND COMPENDIUM SUITE
Sole Inventor & IP Holder: Thomas Gabriel Coleman
Master USPTO Dockets: CPC-PAT-2026-001 through CPC-PAT-2026-005-CIP (31 Claims | FIGS. 1-11)

Contents:
1. Cool_Power_Core_Vol37_and_1850_Grand_Compendium.pdf  - Print-ready landscape Grand Compendium, IP valuation summary, Vol XXXVII catalog (#1,801-#1,850), and 37-Volume Rollup.
2. Cool_Power_Core_Vol37_and_1850_Grand_Compendium.xlsx - 3-tab interactive workbook covering Vol XXXVII, the Grand 37-Volume Rollup (1,850 cases), and the Master USPTO IP Valuation.
3. Cool_Power_Core_Vol37_and_1850_Grand_Compendium.md   - Clean Markdown reference source of the complete Vol XXXVII & 1,850-Application Grand Compendium.
