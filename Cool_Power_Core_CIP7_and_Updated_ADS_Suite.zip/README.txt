COOL POWER CORE (CPC) - CIP-7 & UPDATED USPTO APPLICATION DATA SHEET (43 CLAIMS | 15 FIGURES)
Inventor: Thomas Gabriel Coleman (Corona, CA) | Date: November 26, 2026
Master Docket: CPC-PAT-2026-001-MASTER (Incorporating CPC-PAT-2026-007-CIP)

CONTENTS:
1. Cool_Power_Core_CIP7_and_Updated_ADS.pdf  - Formal CIP-7 Specification (Claims 38-43), 37 CFR 1.84 B&W Line Drawings (FIGS. 14 & 15), and Updated Form PTO/AIA/14 ADS.
2. Cool_Power_Core_CIP7_and_Updated_ADS.xlsx - Consolidated 43-Claim Patent Docket Tracker, FIGS. 14-15 Reference Numeral Concordance, and Structured PTO/AIA/14 ADS Data.
3. Cool_Power_Core_CIP7_and_Updated_ADS.md   - Clean Markdown source of CIP-7 Claims 38-43 and Updated PTO/AIA/14 Application Data Sheet.
