"""
Cool Power Core — Tri-Rail Power & Mixture Controller Simulation (v2.0 Uniform)
Designer: Thomas G. Coleman
"""

from dataclasses import dataclass, asdict
import json


@dataclass
class TelemetrySnapshot:
    scale_tier: str
    mode: str
    fan_enabled: bool
    reservoir_temp_c: float
    venturi_throat_kpa: float
    ntp_voltage_kv: float
    total_harvested_w: float
    high_kv_rail_w: float
    med_v_rail_w: float
    low_v_rail_w: float
    internal_led_fan_dump_w: float
    net_grid_export_w: float


class CoolPowerCoreController:
    SCALE_MULTIPLIERS = {
        "Tier_1_Personal": 1.0,
        "Tier_2_Vehicle": 3.5,
        "Tier_3_Habitat": 6.8,
        "Tier_4_Municipal": 95.0,
    }

    def __init__(self, scale_tier: str = "Tier_1_Personal"):
        if scale_tier not in self.SCALE_MULTIPLIERS:
            raise ValueError(f"Unknown scale_tier: {scale_tier}")
        self.scale_tier = scale_tier
        self.mult = self.SCALE_MULTIPLIERS[scale_tier]
        self.fan_enabled = True
        self.mode = "AUTO_BALANCE"
        self.reservoir_temp_c = 90.0
        self.venturi_throat_kpa = 28.5
        self.ntp_voltage_kv = 14.5

    def harvest_energy_watts(self) -> float:
        if self.fan_enabled:
            pyro_teg_w = 24.0 * self.mult
            pzt_w = 10.5 * self.mult
            turbo_w = 19.5 * self.mult
        else:
            # Passive Venturi ejector mode (~40% throughput)
            pyro_teg_w = 14.5 * self.mult
            pzt_w = 5.5 * self.mult
            turbo_w = 3.0 * self.mult
        return pyro_teg_w + pzt_w + turbo_w

    def step(self) -> TelemetrySnapshot:
        total_w = self.harvest_energy_watts()
        active_mode = self.mode if self.fan_enabled else "PASSIVE_SAFE"

        if active_mode == "PASSIVE_SAFE":
            high_kv_w = total_w * 0.65
            low_v_w = total_w * 0.35
            med_v_w = 0.0
            dump_w = 0.0
        elif active_mode == "MAX_PURIFY":
            high_kv_w = total_w * 0.55
            med_v_w = total_w * 0.22
            low_v_w = total_w * 0.10
            dump_w = total_w * 0.13
        elif active_mode == "MAX_WATER":
            high_kv_w = total_w * 0.42
            med_v_w = total_w * 0.30
            low_v_w = total_w * 0.10
            dump_w = total_w * 0.18
        else:  # AUTO_BALANCE
            high_kv_w = total_w * 0.45
            med_v_w = total_w * 0.25
            low_v_w = total_w * 0.10
            dump_w = total_w * 0.20

        return TelemetrySnapshot(
            scale_tier=self.scale_tier,
            mode=active_mode,
            fan_enabled=self.fan_enabled,
            reservoir_temp_c=self.reservoir_temp_c,
            venturi_throat_kpa=self.venturi_throat_kpa if self.fan_enabled else 46.0,
            ntp_voltage_kv=self.ntp_voltage_kv if self.fan_enabled else 11.5,
            total_harvested_w=round(total_w, 2),
            high_kv_rail_w=round(high_kv_w, 2),
            med_v_rail_w=round(med_v_w, 2),
            low_v_rail_w=round(low_v_w, 2),
            internal_led_fan_dump_w=round(dump_w, 2),
            net_grid_export_w=0.0,
        )


if __name__ == "__main__":
    controller = CoolPowerCoreController("Tier_1_Personal")
    print("=== ACTIVE FAN-ASSISTED MODE ===")
    print(json.dumps(asdict(controller.step()), indent=2))

    controller.fan_enabled = False
    print("\n=== PASSIVE FAIL-SAFE MODE (ZERO FAN / ZERO EXTERNAL POWER) ===")
    print(json.dumps(asdict(controller.step()), indent=2))
