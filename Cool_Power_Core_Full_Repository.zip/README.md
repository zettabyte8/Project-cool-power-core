# Cool Power Core — Full Engineering Repository

**Project:** Cool Power Core  
**Designer:** Thomas G. Coleman  
**System Classification:** Self-Powered Atmospheric Water Harvester & Closed-Loop Air Remediation Unit  
**Primary Outputs:** Potable Remineralized Water + Zero-Emission Purified Air (Zero Net Electrical Export)  
**Version:** 2.0 (Uniform Release)

---

## Repository Structure

```text
Cool_Power_Core_Full_Repository/
├── README.md
├── docs/
│   └── Cool_Power_Core_Engineering_Manual.md
├── bom/
│   └── Bill_of_Materials.csv
├── geometry/
│   ├── CAD_Dimension_Sheet.md
│   └── Nozzle_and_Chamber_Angles.csv
├── firmware/
│   ├── Control_Firmware_Logic.txt
│   └── hmi_controller_sim.py
└── maintenance/
    └── Preventive_Maintenance_Schedule.csv
```

## Core Architecture Summary
1. **Electrostatic Pre-Filtration & Intake:** Humid polluted air passes a high-voltage Ion Capture Grid into a $21.0^\circ$ bellmouth orifice, optionally assisted by a variable-speed intake fan.
2. **Enthalpy & Humidity Conditioning:** Filtered air blends with recycled high-heat exhaust gas and vapor from a $90^\circ\text{C}$ heated water reservoir.
3. **Hydrodynamic Cavitation ("Cold Steam"):** A convergent-divergent Venturi chamber ($21.0^\circ$ convergent / $7.0^\circ$ divergent half-angles) nucleates sub-micron cold-steam droplets.
4. **Non-Thermal Plasma (NTP) Radicalization:** Helical swirl vanes ($30.0^\circ$ axial pitch / $12.0^\circ$ radial cup) route cold steam through a Dielectric Barrier Discharge (DBD) zone generating atomic hydrogen ($H^\bullet$), hydroxyl radicals ($^\bullet OH$), and ozone ($O_3$).
5. **Free-Piston Opposed-Piston (FPOP) Core:** Compression autoignition ($18:1$–$24:1$ compression ratio) oxidizes contaminants without spark plugs, crankshafts, or fossil fuel injection.
6. **Multi-Modal Solid-State & Fluidic Energy Harvesting:** Pyroelectric + TEG arrays, PZT piezoelectric stacks, and an exhaust micro-turbocharger harvest thermal pulses, mechanical shock, and exhaust expansion.
7. **Thermal Exhaust Splitting & Water Condensation:** A Coanda Wye splitter ($25.0^\circ$ high-heat / $15.0^\circ$ low-heat) recycles high-heat exhaust back to the intake/reservoir and routes low-heat vapor through a superhydrophobic graphene condenser ($32.0^\circ$ fin slope) and remineralization bed.
8. **Zero-Export Tri-Rail Power Bus:** Harvested DC power feeds High, Medium, and Low voltage rails. Excess electricity is dissipated internally via LED illumination arrays and circulation fans so net external export remains $0.0\text{ W}$.
9. **Passive Fail-Safe Continuity:** If the intake fan or external power fails, hot exhaust routed into the primary Venturi nozzle sustains fluidic ejector draft at $35\%$–$45\%$ baseline throughput.
