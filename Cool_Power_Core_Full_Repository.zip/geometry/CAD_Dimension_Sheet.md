# CAD Dimension & Invariant Geometry Sheet — Cool Power Core

**Designer:** Thomas G. Coleman  
**Document ID:** `CPC-GEO-2.0`  
**Units:** Millimeters ($	ext{mm}$) and Degrees ($^\circ$)

---

## 1. Invariant Aerodynamic & Fluidic Angles (All Scale Tiers)
To preserve passive Venturi ejector draft, cavitation nucleation, plasma residence time, and dropwise water drainage without recalculating fluid dynamics, **all scale tiers preserve identical internal angles**:

| Feature ID | Subsystem | Geometric Feature | Angle ($^\circ$) | Tolerance ($^\circ$) | Engineering Function |
| :--- | :--- | :--- | :---: | :---: | :--- |
| `ANG-01` | `SUB-01` | Intake Bellmouth Entry Taper | $21.0^\circ$ | $\pm 0.5^\circ$ | Minimizes vena contracta losses during passive fan-off draft |
| `ANG-02` | `SUB-03` | Venturi Convergent Cone Half-Angle | $21.0^\circ$ | $\pm 0.2^\circ$ | Accelerates saturated mixture into sub-atmospheric throat |
| `ANG-03` | `SUB-03` | Venturi Divergent Diffuser Half-Angle | $7.0^\circ$ | $\pm 0.2^\circ$ | Maximizes cavitation bubble collapse without boundary separation |
| `ANG-04` | `SUB-04` | NTP Helical Swirl Vane Axial Pitch | $30.0^\circ$ | $\pm 0.5^\circ$ | Increases plasma radical residence time by $2.4	imes$ |
| `ANG-05` | `SUB-04` | NTP Helical Swirl Vane Radial Cup | $12.0^\circ$ | $\pm 0.5^\circ$ | Distributes cold-steam mist uniformly across dielectric gap |
| `ANG-06` | `SUB-05` | FPOP Scavenging Intake Port Entry | $45.0^\circ$ | $\pm 0.3^\circ$ | Establishes uniflow loop scavenging in combustion cylinder |
| `ANG-07` | `SUB-09` | Thermal Splitter High-Heat Branch | $25.0^\circ$ | $\pm 0.5^\circ$ | Routes hot core exhaust back to intake mixer & $90^\circ\text{C}$ reservoir |
| `ANG-08` | `SUB-09` | Thermal Splitter Low-Heat Branch | $15.0^\circ$ | $\pm 0.5^\circ$ | Directs cooler vapor boundary layer into condenser matrix |
| `ANG-09` | `SUB-10` | Condenser Drainage Fin Slope | $32.0^\circ$ | $\pm 1.0^\circ$ | Accelerates gravity-driven dropwise water shedding |
| `ANG-10` | `SUB-11` | Exhaust Ion Polisher Louver Angle | $18.0^\circ$ | $\pm 0.5^\circ$ | Captures sub-micron aerosols at $<15\text{ Pa}$ pressure drop |

---

## 2. Parametric Scaling Matrix (Dimensions in mm)

| Parameter | Tier 1: Personal ($1\times$) | Tier 2: Vehicle ($1.85\times$) | Tier 3: Habitat/Deep-Sea ($2.43\times$) | Tier 4: Municipal ($7.85\times$) |
| :--- | :---: | :---: | :---: | :---: |
| **Intake Orifice Diameter ($D_{\text{in}}$)** | $32.0$ | $59.2$ | $77.8$ | $251.2$ |
| **Venturi Throat Diameter ($D_{\text{th}}$)** | $11.5$ | $21.3$ | $27.9$ | $90.3$ |
| **NTP Chamber Inner Bore ($D_{\text{ntp}}$)** | $36.0$ | $66.6$ | $87.5$ | $282.6$ |
| **NTP Chamber Active Length ($L_{\text{ntp}}$)** | $110.0$ | $203.5$ | $267.3$ | $863.5$ |
| **FPOP Cylinder Bore ($B_{\text{fpop}}$)** | $28.0$ | $51.8$ | $68.0$ | $219.8$ |
| **FPOP Single-Piston Stroke ($S_{\text{fpop}}$)** | $34.0$ | $62.9$ | $82.6$ | $266.9$ |
| **Aerogel Insulation Wall Thickness ($t_{\text{ins}}$)** | $25.0$ | $35.0$ | $45.0$ | $75.0$ |
| **Condenser Surface Area ($\text{m}^2$)** | $0.45$ | $1.55$ | $2.80$ | $28.50$ |
| **Overall Enclosure ($L \times W \times H$)** | $340 \times 210 \times 260$ | $620 \times 380 \times 470$ | $810 \times 500 \times 620$ | $2600 \times 1600 \times 1980$ |
