COOL POWER CORE (CPC) - FRONTIER EXPANSIONS, USPTO CHECKLIST & 50 USE-CASE SUITE
Inventor: Thomas Gabriel Coleman
Docket Series: CPC-PAT-2026-001 through CPC-PAT-2026-005-CIP

Included Files:
1. Cool_Power_Core_Frontier_USPTO_and_50_Use_Cases.pdf  - Print-ready technical specs for CPC-TRANS & CPC-CRYO-ECLSS, 8-item USPTO ADS/Oath filing checklist, and complete 50-application encyclopedia.
2. Cool_Power_Core_50_Use_Cases_and_USPTO_Checklist.xlsx - Filterable Excel matrix of all 50 commercial, defense, industrial, remediation, suit/robotics, and space applications + USPTO checklist.
3. Cool_Power_Core_Frontier_USPTO_and_50_Use_Cases.md   - Clean Markdown reference source.
