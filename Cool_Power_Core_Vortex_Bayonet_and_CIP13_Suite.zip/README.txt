COOL POWER CORE (CPC) - VORTEX-BAYONET MK. II & USPTO CIP-13 SUITE
Inventor: Thomas Gabriel Coleman
Contents:
1. Cool_Power_Core_Vortex_Bayonet_Blueprint_and_CIP13.pdf
2. Cool_Power_Core_Vortex_Bayonet_and_CIP13.xlsx
3. Cool_Power_Core_ePCT_Claims_74_to_77_v9.xml
4. Cool_Power_Core_Vortex_Rifle_Plasma_Bayonet.md
