COOL POWER CORE (CPC) — MASTER PATENT PORTFOLIO v3 & FRONTIER PLASMA TOOLS SUITE
Inventor: Thomas Gabriel Coleman (Corona, California, USA)
Date: November 26, 2026

INCLUDED FILES:
1. Cool_Power_Core_Master_Patent_Portfolio_Volume_v3.pdf  - Consolidated Master Patent Volume v3 (Claims 1-37 | FIGS. 1-13)
2. Cool_Power_Core_Master_Patent_Portfolio_Volume_v3.md   - Editable Markdown source for Master Patent Volume v3
3. Cool_Power_Core_Frontier_Plasma_Tools.md             - Deep-Sea Hydrothermal Torch (6,000 m) & Asteroid Zero-Recoil Plasma Rock-Splitter
4. Cool_Power_Core_Master_Patent_v3_and_Frontier_Tools.xlsx - Structured Excel docket & frontier plasma tool engineering matrix
