// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title CoolPowerCoreReserveCoinV3 (CPC-COIN)
 * @author Thomas Gabriel Coleman (Corona, CA)
 * @notice Multi-currency yield-compounding reserve savings & UBI coin for Cool Power Core: Horizons Unbound.
 *         Integrates Lido wstETH, Sky sUSDS, Beefy.com autocompounding vaults, Aerodrome Finance (Base 8453),
 *         and Robinhood Chain L2 (46630) tokenized equity/T-bill settlement.
 *         100% of swap fees and external staking/LP yields recycle into global NAV without token dilution.
 */

interface IERC20 {
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address to, uint256 value) external returns (bool);
    function transferFrom(address from, address to, uint256 value) external returns (bool);
    function approve(address spender, uint256 value) external returns (bool);
}

interface IPriceOracle {
    function getPriceUSD18(address asset) external view returns (uint256);
}

interface ILidoWstETH {
    function wrap(uint256 stETHAmount) external returns (uint256);
    function unwrap(uint256 wstETHAmount) external returns (uint256);
    function stEthPerToken() external view returns (uint256);
}

interface IBeefyVault {
    function deposit(uint256 amount) external;
    function withdraw(uint256 shares) external;
    function getPricePerFullShare() external view returns (uint256);
}

interface IAerodromeGauge {
    function deposit(uint256 amount) external;
    function withdraw(uint256 amount) external;
    function getReward(address account) external;
}

interface IBridgeRouter {
    function dispatchYieldPayload(uint32 dstChainId, address asset, uint256 amount, bytes calldata routeData) external payable;
}

contract CoolPowerCoreReserveCoinV3 {
    string public constant name = "Cool Power Core Reserve Coin";
    string public constant symbol = "CPC";
    uint8 public constant decimals = 18;

    uint256 public constant BASE_CHAIN_ID = 8453;
    uint256 public constant ROBINHOOD_CHAIN_ID = 46630;
    uint256 public constant SWAP_FEE_BPS = 25; // 0.25% recycled 100% to NAV
    uint256 public constant BPS_DENOMINATOR = 10_000;

    // Capital Allocation Targets (Sum = 10,000 bps)
    uint256 public constant LIQUID_BUFFER_BPS = 1500;      // 15% instant any-currency redemption buffer
    uint256 public constant LIDO_BEEFY_CORE_BPS = 4500;    // 45% Lido wstETH + Sky sUSDS + Beefy.com vaults
    uint256 public constant AERODROME_BASE_BPS = 2500;     // 25% Aerodrome Finance (Base) CPC/USDC, CPC/wstETH, CPC/cbBTC gauges
    uint256 public constant ROBINHOOD_L2_BPS = 1500;       // 15% Robinhood Chain L2 RWA T-Bill & equity mirror settlement

    address public governance;
    IPriceOracle public oracle;
    IBridgeRouter public ccipRouter;

    uint256 public totalSupply;
    uint256 public cumulativeFeesRecycledUSD18;
    uint256 public cumulativeYieldHarvestedUSD18;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    struct ReserveAsset {
        bool supported;
        uint8 assetDecimals;
        address beefyVault;
        address aerodromeGauge;
        uint256 liquidBalance;
        uint256 deployedPrincipal;
        uint256 accruedYield;
    }

    address[] public supportedAssets;
    mapping(address => ReserveAsset) public reserves;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
    event Deposited(address indexed user, address indexed asset, uint256 amountIn, uint256 cpcMinted, uint256 navUSD18);
    event Redeemed(address indexed user, address indexed assetOut, uint256 cpcBurned, uint256 amountOut, uint256 navUSD18);
    event CrossPairSwapped(address indexed trader, address indexed assetIn, address indexed assetOut, uint256 feeUSD18, uint256 newNavUSD18);
    event YieldCompounded(uint256 lidoBeefyUSD18, uint256 aerodromeAeroUSD18, uint256 robinhoodRwaUSD18, uint256 newNavUSD18);
    event CrossChainRebalanced(uint32 indexed dstChainId, address indexed asset, uint256 amount);

    modifier onlyGovernance() {
        require(msg.sender == governance, "CPC: unauthorized");
        _;
    }

    constructor(address _oracle, address _ccipRouter) {
        governance = msg.sender;
        oracle = IPriceOracle(_oracle);
        ccipRouter = IBridgeRouter(_ccipRouter);
    }

    function registerAsset(
        address asset,
        uint8 assetDecimals,
        address beefyVault,
        address aerodromeGauge
    ) external onlyGovernance {
        require(!reserves[asset].supported, "CPC: already supported");
        reserves[asset] = ReserveAsset({
            supported: true,
            assetDecimals: assetDecimals,
            beefyVault: beefyVault,
            aerodromeGauge: aerodromeGauge,
            liquidBalance: 0,
            deployedPrincipal: 0,
            accruedYield: 0
        });
        supportedAssets.push(asset);
    }

    /// @notice Computes the aggregate USD value (1e18 scaled) of all deposited currencies + staked yields + fees
    function totalBasketValueUSD18() public view returns (uint256 totalUSD18) {
        uint256 len = supportedAssets.length;
        for (uint256 i = 0; i < len; i++) {
            address asset = supportedAssets[i];
            ReserveAsset memory r = reserves[asset];
            uint256 rawTotal = r.liquidBalance + r.deployedPrincipal + r.accruedYield;
            if (rawTotal > 0) {
                uint256 priceUSD18 = oracle.getPriceUSD18(asset);
                uint256 normalized = (rawTotal * (10 ** 18)) / (10 ** r.assetDecimals);
                totalUSD18 += (normalized * priceUSD18) / 1e18;
            }
        }
    }

    /// @notice Net Asset Value (NAV) per 1.0 CPC coin in USD (1e18). Starts at $1.000000000000000000.
    function navPerCoinUSD18() public view returns (uint256) {
        if (totalSupply == 0) return 1e18;
        return (totalBasketValueUSD18() * 1e18) / totalSupply;
    }

    /// @notice Deposit ANY supported currency (USDC, EURC, ETH/wstETH, cbBTC, USDS) to mint CPC at live NAV
    function depositAnyCurrency(address asset, uint256 amountIn) external returns (uint256 cpcMinted) {
        ReserveAsset storage r = reserves[asset];
        require(r.supported && amountIn > 0, "CPC: invalid deposit");

        uint256 currentNav = navPerCoinUSD18();
        require(IERC20(asset).transferFrom(msg.sender, address(this), amountIn), "CPC: transferFrom failed");

        uint256 priceUSD18 = oracle.getPriceUSD18(asset);
        uint256 normalizedIn = (amountIn * (10 ** 18)) / (10 ** r.assetDecimals);
        uint256 depositUSD18 = (normalizedIn * priceUSD18) / 1e18;

        cpcMinted = (depositUSD18 * 1e18) / currentNav;
        r.liquidBalance += amountIn;

        totalSupply += cpcMinted;
        balanceOf[msg.sender] += cpcMinted;

        emit Transfer(address(0), msg.sender, cpcMinted);
        emit Deposited(msg.sender, asset, amountIn, cpcMinted, navPerCoinUSD18());
    }

    /// @notice Redeem CPC at any time for ANY currency in the global reserve basket
    function redeemForAnyCurrency(uint256 cpcBurned, address assetOut) external returns (uint256 amountOut) {
        ReserveAsset storage r = reserves[assetOut];
        require(r.supported && cpcBurned > 0 && balanceOf[msg.sender] >= cpcBurned, "CPC: invalid redeem");

        uint256 currentNav = navPerCoinUSD18();
        uint256 redeemUSD18 = (cpcBurned * currentNav) / 1e18;
        uint256 priceUSD18 = oracle.getPriceUSD18(assetOut);

        uint256 normalizedOut = (redeemUSD18 * 1e18) / priceUSD18;
        amountOut = (normalizedOut * (10 ** r.assetDecimals)) / (10 ** 18);
        require(r.liquidBalance >= amountOut, "CPC: rebalance buffer required");

        balanceOf[msg.sender] -= cpcBurned;
        totalSupply -= cpcBurned;
        r.liquidBalance -= amountOut;

        require(IERC20(assetOut).transfer(msg.sender, amountOut), "CPC: transfer failed");
        emit Transfer(msg.sender, address(0), cpcBurned);
        emit Redeemed(msg.sender, assetOut, cpcBurned, amountOut, navPerCoinUSD18());
    }

    /// @notice AI Merchant & Player DEX Swap: 0.25% fee stays inside reserve basket, ratcheting up CPC NAV
    function swapReservePairs(address assetIn, address assetOut, uint256 amountIn) external returns (uint256 amountOut) {
        ReserveAsset storage rIn = reserves[assetIn];
        ReserveAsset storage rOut = reserves[assetOut];
        require(rIn.supported && rOut.supported && assetIn != assetOut && amountIn > 0, "CPC: invalid pair");

        require(IERC20(assetIn).transferFrom(msg.sender, address(this), amountIn), "CPC: transferFrom failed");

        uint256 feeIn = (amountIn * SWAP_FEE_BPS) / BPS_DENOMINATOR;
        uint256 netIn = amountIn - feeIn;

        // Full amountIn (including 0.25% fee) enters reserve basket
        rIn.liquidBalance += amountIn;

        uint256 priceIn = oracle.getPriceUSD18(assetIn);
        uint256 priceOut = oracle.getPriceUSD18(assetOut);

        uint256 netInUSD18 = (((netIn * (10 ** 18)) / (10 ** rIn.assetDecimals)) * priceIn) / 1e18;
        uint256 feeUSD18 = (((feeIn * (10 ** 18)) / (10 ** rIn.assetDecimals)) * priceIn) / 1e18;

        amountOut = (((netInUSD18 * 1e18) / priceOut) * (10 ** rOut.assetDecimals)) / (10 ** 18);
        require(rOut.liquidBalance >= amountOut, "CPC: insufficient pair liquidity");

        rOut.liquidBalance -= amountOut;
        cumulativeFeesRecycledUSD18 += feeUSD18;

        require(IERC20(assetOut).transfer(msg.sender, amountOut), "CPC: swap transfer failed");
        emit CrossPairSwapped(msg.sender, assetIn, assetOut, feeUSD18, navPerCoinUSD18());
    }

    /// @notice Harvests Lido wstETH, Beefy.com vaults, Aerodrome (Base) AERO gauges, and Robinhood L2 yields into NAV
    function compoundAllMultiChainYields(
        address asset,
        uint256 lidoBeefyGain,
        uint256 aerodromeGain,
        uint256 robinhoodL2Gain
    ) external onlyGovernance {
        ReserveAsset storage r = reserves[asset];
        require(r.supported, "CPC: unsupported");

        uint256 totalGain = lidoBeefyGain + aerodromeGain + robinhoodL2Gain;
        r.accruedYield += totalGain;

        uint256 priceUSD18 = oracle.getPriceUSD18(asset);
        uint256 gainUSD18 = (((totalGain * (10 ** 18)) / (10 ** r.assetDecimals)) * priceUSD18) / 1e18;
        cumulativeYieldHarvestedUSD18 += gainUSD18;

        emit YieldCompounded(lidoBeefyGain, aerodromeGain, robinhoodL2Gain, navPerCoinUSD18());
    }

    /// @notice Dispatches cross-chain liquidity between Ethereum (1), Base Aerodrome (8453), and Robinhood Chain (46630)
    function bridgeToYieldChain(uint32 dstChainId, address asset, uint256 amount, bytes calldata routeData) external payable onlyGovernance {
        ReserveAsset storage r = reserves[asset];
        require(r.liquidBalance >= amount, "CPC: insufficient liquid balance");
        r.liquidBalance -= amount;
        r.deployedPrincipal += amount;
        IERC20(asset).approve(address(ccipRouter), amount);
        ccipRouter.dispatchYieldPayload{value: msg.value}(dstChainId, asset, amount, routeData);
        emit CrossChainRebalanced(dstChainId, asset, amount);
    }

    function transfer(address to, uint256 value) external returns (bool) {
        require(balanceOf[msg.sender] >= value, "CPC: insufficient balance");
        balanceOf[msg.sender] -= value;
        balanceOf[to] += value;
        emit Transfer(msg.sender, to, value);
        return true;
    }

    function approve(address spender, uint256 value) external returns (bool) {
        allowance[msg.sender][spender] = value;
        emit Approval(msg.sender, spender, value);
        return true;
    }

    function transferFrom(address from, address to, uint256 value) external returns (bool) {
        require(balanceOf[from] >= value && allowance[from][msg.sender] >= value, "CPC: allowance/balance");
        allowance[from][msg.sender] -= value;
        balanceOf[from] -= value;
        balanceOf[to] += value;
        emit Transfer(from, to, value);
        return true;
    }
}
