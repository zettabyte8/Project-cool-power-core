Cool Power Core (uCPC-ROBO) — CIP-4 Patent Drawings & Simulation Theater Suite
Inventor: Thomas Gabriel Coleman

Contents:
1. Cool_Power_Core_CIP4_Patent_Drawings_FIG8_FIG9.pdf : Formal USPTO black-and-white patent line drawings (FIG. 8 & FIG. 9) for Docket CPC-PAT-2026-004-CIP.
2. cpc_robo_theater_launch.py                          : ROS 2 / Gazebo Harmonic / Isaac Sim Python launch script.
3. cpc_robo_multi_frontier_theater.world               : SDF 3D simulation world with Urban Shootout, Martian Terraforming, and Subsurface Ice zones.
4. Cool_Power_Core_CIP4_Drawings_and_Theater_Guide.md  : Reference numeral index and ROS 2 simulation quick-start guide.
