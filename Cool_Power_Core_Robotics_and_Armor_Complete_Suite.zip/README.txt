COOL POWER CORE (CPC) — ROBOTICS, POWER ARMOR MK3 & ATMOSPHERIC-SLUG RIFLE SUITE
Inventor: Thomas Gabriel Coleman (Corona, California)
Date: November 27, 2026

CONTENTS:
1. Cool_Power_Core_Armor_Upgrade_and_Atmos_Rifle.md   - Full engineering spec for CPC-PA-MK3 & CPC-RIFLE-ATMOS
2. Cool_Power_Core_Armor_Upgrade_and_Atmos_Rifle.pdf  - Print-ready landscape blueprint & closed-loop schematic
3. Cool_Power_Core_Robotics_and_Armor_Master.xlsx     - Formula-driven BOM, kinematics & energy-conversion workbook
