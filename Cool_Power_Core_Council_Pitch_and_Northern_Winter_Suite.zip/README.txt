COOL POWER CORE (CPC) - CITY COUNCIL PITCH DECK & NORTHERN WINTER SANCTUARY SUITE
Inventor & Architect: Thomas Gabriel Coleman | Corona, CA | November 26, 2026

INCLUDED FILES:
1. Cool_Power_Core_City_Council_Pitch_Deck.pptx       - 6-slide executive briefing deck for City Councils, County Supervisors & State Housing Officials
2. Cool_Power_Core_Northern_Winter_and_Council_Spec.pdf - Print-ready landscape specification with 4-layer ETFE sub-zero cross-section schematic
3. Cool_Power_Core_Northern_Winter_and_Council_Model.xlsx - Formula-driven comparison, seasonal energy balance (-35C to +34C) & P3 capital stack workbook
4. Cool_Power_Core_Northern_Winter_and_Council_Brief.md - Editable Markdown technical & civic reference
