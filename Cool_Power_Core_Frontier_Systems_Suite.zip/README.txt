COOL POWER CORE™ (CPC) — FRONTIER SYSTEMS SUITE (CASES #1,851 & #1,852)
Inventor: Thomas Gabriel Coleman (Corona, CA)
Date: November 26, 2026

CONTENTS:
1. Cool_Power_Core_Frontier_Systems_Spec.pdf  - Print-ready landscape engineering specification with vector schematics.
2. Cool_Power_Core_Frontier_Systems_Model.xlsx - Formula-driven performance, co-product, and per-core energy balance workbook.
3. Cool_Power_Core_Frontier_Systems_Spec.md   - Complete Markdown engineering documentation.
4. README.txt                                 - Archive index.
