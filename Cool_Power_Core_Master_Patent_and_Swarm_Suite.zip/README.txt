COOL POWER CORE (TM) - MASTER PATENT PORTFOLIO & AUTONOMOUS SWARM SUITE
Inventor: Thomas Gabriel Coleman

Contents:
1. Cool_Power_Core_Master_Patent_Portfolio_Volume.pdf
   - Consolidated USPTO patent portfolio covering CPC-PAT-2026-001 (Parent Utility)
     plus CIP-2 (Radiation Harvesting), CIP-3 (Exoskeleton Life Support), and
     CIP-4 (Biomimetic Autonomous Companion), Claims 1-25 and FIGS. 1-9.
2. Cool_Power_Core_Swarm_Mesh_Protocol.md
   - 3-Tier UWB/802.11s/LoRa swarm coordination & peer-to-peer 48V + 90C H2O sharing spec.
3. cpc_robo_swarm_mesh_coordinator.py
   - Executable Python swarm auction & interlocking ballistic shield phalanx simulation.
