// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title CoolPowerCoreReserveCoinV3 (CPC-COIN)
/// @author Thomas Gabriel Coleman
/// @notice Multi-currency NAV-compounding reserve token integrating Lido wstETH,
///         Beefy.com autocompounding vaults, Aerodrome Finance gauges on Base (8453),
///         and Robinhood Chain L2 (46630) tokenized yield sweeps.
interface IERC20 {
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address to, uint256 amount) external returns (bool);
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
    function approve(address spender, uint256 amount) external returns (bool);
}

interface IAerodromeGauge {
    function deposit(uint256 amount) external;
    function withdraw(uint256 amount) external;
    function getReward(address account) external;
}

interface IBeefyVault {
    function deposit(uint256 _amount) external;
    function withdraw(uint256 _shares) external;
    function getPricePerFullShare() external view returns (uint256);
}

interface IPriceOracle {
    function getAssetPriceUSD18(address asset) external view returns (uint256);
}

contract CoolPowerCoreReserveCoinV3 {
    string public constant name = "Cool Power Core Reserve Coin";
    string public constant symbol = "CPC";
    uint8 public constant decimals = 18;

    uint256 public totalSupply;
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    address public governance;
    IPriceOracle public oracle;

    // Allocation targets in basis points (10000 = 100%)
    uint256 public constant LIQUID_BUFFER_BPS = 1500;     // 15% instant any-currency redemption
    uint256 public constant AERODROME_BASE_BPS = 2500;    // 25% Base (8453) Aerodrome Gauges
    uint256 public constant LIDO_WSTETH_BPS = 2500;       // 25% Lido wstETH staking
    uint256 public constant BEEFY_VAULT_BPS = 2000;       // 20% Beefy.com + Sky sUSDS vaults
    uint256 public constant ROBINHOOD_L2_BPS = 1500;      // 15% Robinhood Chain (46630) bridge
    uint256 public constant SWAP_FEE_BPS = 25;            // 0.25% recycled 100% into NAV

    address[] public supportedAssets;
    mapping(address => bool) public isSupportedAsset;
    mapping(address => uint256) public externalYieldDeployedUSD18;

    event DepositMinted(address indexed user, address indexed asset, uint256 amountIn, uint256 cpcMinted, uint256 navUSD18);
    event Redeemed(address indexed user, address indexed assetOut, uint256 cpcBurned, uint256 amountOut, uint256 navUSD18);
    event CrossPairSwapFeeRecycled(address indexed trader, address assetIn, address assetOut, uint256 feeUSD18, uint256 newNavUSD18);
    event YieldCompounded(string sourceProtocol, uint256 yieldAddedUSD18, uint256 newNavUSD18);

    modifier onlyGovernance() {
        require(msg.sender == governance, "CPC: unauthorized");
        _;
    }

    constructor(address _oracle) {
        governance = msg.sender;
        oracle = IPriceOracle(_oracle);
    }

    function addSupportedAsset(address asset) external onlyGovernance {
        require(!isSupportedAsset[asset], "CPC: already listed");
        isSupportedAsset[asset] = true;
        supportedAssets.push(asset);
    }

    /// @notice Returns total USD value (1e18) of all liquid reserves + staked/deployed vaults
    function totalBasketValueUSD18() public view returns (uint256 totalUSD) {
        uint256 len = supportedAssets.length;
        for (uint256 i = 0; i < len; i++) {
            address asset = supportedAssets[i];
            uint256 bal = IERC20(asset).balanceOf(address(this));
            uint256 px = oracle.getAssetPriceUSD18(asset);
            totalUSD += (bal * px) / 1e18 + externalYieldDeployedUSD18[asset];
        }
    }

    /// @notice Current Net Asset Value per CPC coin in 18-decimal USD ($1.00 = 1e18)
    function navPerCoinUSD18() public view returns (uint256) {
        if (totalSupply == 0) return 1e18;
        return (totalBasketValueUSD18() * 1e18) / totalSupply;
    }

    /// @notice Deposit any supported currency to mint CPC coins at current basket NAV
    function depositAnyCurrency(address asset, uint256 amountIn) external returns (uint256 cpcMinted) {
        require(isSupportedAsset[asset] && amountIn > 0, "CPC: invalid deposit");
        uint256 currentNav = navPerCoinUSD18();
        uint256 depositUSD18 = (amountIn * oracle.getAssetPriceUSD18(asset)) / 1e18;

        require(IERC20(asset).transferFrom(msg.sender, address(this), amountIn), "CPC: transfer failed");
        cpcMinted = (depositUSD18 * 1e18) / currentNav;

        totalSupply += cpcMinted;
        balanceOf[msg.sender] += cpcMinted;
        emit DepositMinted(msg.sender, asset, amountIn, cpcMinted, navPerCoinUSD18());
    }

    /// @notice Redeem CPC coins at any time for any supported underlying reserve currency
    function redeemAnyCurrency(address assetOut, uint256 cpcAmount) external returns (uint256 amountOut) {
        require(isSupportedAsset[assetOut] && cpcAmount > 0, "CPC: invalid redeem");
        require(balanceOf[msg.sender] >= cpcAmount, "CPC: insufficient CPC");

        uint256 currentNav = navPerCoinUSD18();
        uint256 redeemUSD18 = (cpcAmount * currentNav) / 1e18;
        amountOut = (redeemUSD18 * 1e18) / oracle.getAssetPriceUSD18(assetOut);
        require(IERC20(assetOut).balanceOf(address(this)) >= amountOut, "CPC: rebalance buffer");

        balanceOf[msg.sender] -= cpcAmount;
        totalSupply -= cpcAmount;
        require(IERC20(assetOut).transfer(msg.sender, amountOut), "CPC: payout failed");
        emit Redeemed(msg.sender, assetOut, cpcAmount, amountOut, navPerCoinUSD18());
    }

    /// @notice Cross-pair DEX swap with 0.25% fee retained 100% inside the reserve basket
    function swapReservePair(address assetIn, address assetOut, uint256 amountIn) external returns (uint256 amountOut) {
        require(isSupportedAsset[assetIn] && isSupportedAsset[assetOut] && assetIn != assetOut, "CPC: bad pair");
        require(IERC20(assetIn).transferFrom(msg.sender, address(this), amountIn), "CPC: pull failed");

        uint256 feeIn = (amountIn * SWAP_FEE_BPS) / 10000;
        uint256 netIn = amountIn - feeIn;
        uint256 netUSD18 = (netIn * oracle.getAssetPriceUSD18(assetIn)) / 1e18;
        amountOut = (netUSD18 * 1e18) / oracle.getAssetPriceUSD18(assetOut);

        require(IERC20(assetOut).balanceOf(address(this)) >= amountOut, "CPC: insufficient liquidity");
        require(IERC20(assetOut).transfer(msg.sender, amountOut), "CPC: swap send failed");

        uint256 feeUSD18 = (feeIn * oracle.getAssetPriceUSD18(assetIn)) / 1e18;
        emit CrossPairSwapFeeRecycled(msg.sender, assetIn, assetOut, feeUSD18, navPerCoinUSD18());
    }

    /// @notice Harvests Aerodrome AERO gauge rewards, Lido wstETH, Beefy vaults, and Robinhood L2 sweeps into NAV
    function recordCompoundedYield(address asset, string calldata protocol, uint256 yieldUSD18) external onlyGovernance {
        require(isSupportedAsset[asset], "CPC: unlisted asset");
        externalYieldDeployedUSD18[asset] += yieldUSD18;
        emit YieldCompounded(protocol, yieldUSD18, navPerCoinUSD18());
    }
}
