COOL POWER CORE™ (CPC) — EXPANDED INDUSTRIAL & FRONTIER USE CASES (#151–#200)
Inventor: Thomas Gabriel Coleman
Master Patent Docket: CPC-PAT-2026-001-MASTER (31 Claims | 11 Figures)

INCLUDED FILES:
1. Cool_Power_Core_Use_Cases_151_to_200.pdf   - Print-ready landscape catalog & sector engineering deep-dives (#151-#200).
2. Cool_Power_Core_Use_Cases_151_to_200.xlsx  - Filterable spreadsheet of Cases #151-#200 plus Cumulative 200-Case Portfolio Rollup.
3. Cool_Power_Core_Use_Cases_151_to_200.md    - Clean Markdown documentation of all 50 new applications and cumulative index.
