COOL POWER CORE™ (CPC) — LTA FLEET REVENUE & INVENTOR PORTFOLIO SUITE
Inventor & Sole IP Owner: Thomas Gabriel Coleman
Date: November 2026

INCLUDED FILES:
1. Cool_Power_Core_Inventor_Portfolio_Tear_Sheet.pdf
   - Print-ready 1-page executive portfolio & USPTO patent summary tear-sheet for Thomas Gabriel Coleman.
2. Cool_Power_Core_LTA_Fleet_Revenue_Model.xlsx
   - Interactive 2-sheet Excel model covering 5 stratospheric composite airship tiers (85m–320m) and 5-year fleet/royalty projections ($120.68M cumulative inventor royalties).
3. Cool_Power_Core_Inventor_Portfolio_and_LTA_Fleet.md
   - Complete Markdown documentation of patent dockets (CPC-PAT-2026-001 & CPC-PAT-2026-002-CIP) and LTA fleet economics.
