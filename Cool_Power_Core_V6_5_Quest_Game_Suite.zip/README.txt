Cool Power Core(TM): Horizons Unbound (v6.5 — 3D WebGL, NPC Quests & CPC-COIN)
Architect & Inventor: Thomas Gabriel Coleman (Corona, CA)

Files Included:
1. Cool_Power_Core_Horizons_Playable_Browser_Game.html — Double-click to play at 60 FPS in any browser (Android, Console, Desktop, Haptic/Brain Hat).
2. CoolPowerCore_Quest_Negotiation_Engine.hpp — Zero-allocation C++20 engine header for NPC bidding wars & interplanetary transit.
3. Cool_Power_Core_Quest_and_Economy_Guide.md — Complete documentation of the NPC quest economy, ETF dividend backing & patronage endpoints.
