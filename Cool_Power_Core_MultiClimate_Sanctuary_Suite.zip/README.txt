COOL POWER CORE (CPC) MULTI-CLIMATE SANCTUARY CITY & FRANCHISE REPLICATION SUITE
Inventor & Architect: Thomas Gabriel Coleman (Corona, California)
Date: November 26, 2026

CONTENTS:
1. Cool_Power_Core_MultiClimate_Sanctuary_Manual.pdf  - Print-ready landscape manual comparing Inland Desert, Sub-Zero Winter, Coastal Hurricane, and Off-Grid Island campuses with vector franchise flywheel diagram.
2. Cool_Power_Core_MultiClimate_Sanctuary_Manual.xlsx - 3-tab workbook (4_Climate_Zones_Comparison, 50_Campus_Replication_Model, 90Day_Franchise_SOP).
3. Cool_Power_Core_MultiClimate_Sanctuary_Manual.md   - Clean Markdown engineering, legal charter, and franchise replication manual.
4. README.txt                                         - Package index.
