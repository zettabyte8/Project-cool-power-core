Cool Power Core™ Terrestrial Exoskeleton Suit (CPC-EXO-EXT) Package
Inventor / Designer: Thomas Gabriel Coleman

Included Files:
1. Cool_Power_Core_Terrestrial_Exoskeleton_Spec.pdf   - Print-ready engineering specification & schematic
2. Cool_Power_Core_Terrestrial_Exoskeleton_Model.xlsx - Formula-driven duty-cycle & mass-budget workbook
3. Cool_Power_Core_Terrestrial_Exoskeleton_Suit.md    - Full technical engineering documentation
