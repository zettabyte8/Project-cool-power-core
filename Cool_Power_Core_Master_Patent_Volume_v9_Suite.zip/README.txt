COOL POWER CORE™ (CPC) — MASTER PATENT PORTFOLIO VOLUME v9 (77 CLAIMS | 26 FIGURES)
Inventor & Applicant: Thomas Gabriel Coleman (Corona, California, USA)
Date: November 27, 2026

INCLUDED FILES:
1. Cool_Power_Core_Master_Patent_Volume_v9.pdf     - Print-ready consolidated patent volume (13 U.S. + 1 PCT, 77 Claims, 26 Figures)
2. Cool_Power_Core_ePCT_Full_Application_v9.xml    - Validated WIPO ST.36 v1.9 UTF-8 XML filing body for direct ePCT / Patent Center upload
3. Cool_Power_Core_Master_Patent_v9_77Claims.xlsx  - Structured 3-tab Excel docket, 77-claim register, and portfolio audit workbook
4. Cool_Power_Core_Master_Patent_Volume_v9.md      - Editable Markdown master patent specification and 77-claim register
5. README.txt                                      - Archive manifest and filing summary
