COOL POWER CORE(TM): HORIZONS UNBOUND - AI ADVISOR COUNCIL SUITE
Invented by Thomas Gabriel Coleman (Corona, CA)

Included Files:
1. Cool_Power_Core_Horizons_Playable_Browser_Game.html - Standalone 60 FPS browser game with interactive Gemini AI (google.com), Venice.ai, and Game Master AI characters.
2. CoolPowerCore_AI_Advisors_and_Runtime.hpp - C++20 zero-allocation engine header for multi-AI persona context snapshots.
3. Cool_Power_Core_AI_Council_Guide.md - Architecture and integration documentation.
