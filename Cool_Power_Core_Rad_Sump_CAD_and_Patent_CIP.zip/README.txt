COOL POWER CORE (CPC-RAD-HV) - CAD & PATENT CONTINUATION ARCHIVE
Inventor: Thomas G. Coleman | Docket: CPC-PAT-2026-002-CIP

Included Files:
1. Cool_Power_Core_Rad_Sump_CAD_Cross_Section.pdf - Mechanical cross-section & GD&T blueprint of the 4H-SiC betavoltaic & W-B4C gamma-shielded sump assembly.
2. Cool_Power_Core_Radiation_Harvesting_Patent_CIP.pdf - Print-ready USPTO Continuation-in-Part patent specification & claims (Claims 8-13).
3. Cool_Power_Core_Radiation_Harvesting_Patent_CIP.md - Clean Markdown source of the CIP patent specification & claims.
