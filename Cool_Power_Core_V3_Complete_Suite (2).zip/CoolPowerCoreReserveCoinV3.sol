// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title CoolPowerCoreReserveCoinV3 (CPC-COIN)
/// @author Thomas Gabriel Coleman
/// @notice Multi-currency reserve savings token compounding via Lido wstETH, Beefy.com, Aerodrome (Base 8453), and Robinhood Chain (46630).
contract CoolPowerCoreReserveCoinV3 {
    string public constant name = "Cool Power Core Reserve Coin";
    string public constant symbol = "CPC";
    uint8 public constant decimals = 18;

    uint256 public totalSupply;
    uint256 public totalReserveBasketUSD18; // Aggregate USD value (18 decimals) of all deposited currencies
    uint256 public constant SWAP_FEE_BPS = 25; // 0.25% recycled 100% into NAV

    // Capital Allocation Targets (BPS = 10,000)
    uint256 public constant ALLOC_AERODROME_BASE_BPS = 2500; // 25% Aerodrome Finance (Base 8453)
    uint256 public constant ALLOC_LIDO_WSTETH_BPS    = 3000; // 30% Lido wstETH Staking
    uint256 public constant ALLOC_BEEFY_SKY_BPS      = 1500; // 15% Beefy.com & Sky sUSDS Vaults
    uint256 public constant ALLOC_ROBINHOOD_L2_BPS   = 1500; // 15% Robinhood Chain L2 (46630)
    uint256 public constant ALLOC_LIQUID_BUFFER_BPS  = 1500; // 15% Instant Any-Currency Redemption Buffer

    mapping(address => uint256) public balanceOf;
    mapping(address => uint256) public assetUSDPrice18;
    mapping(address => uint256) public vaultAssetBalance;

    event Deposited(address indexed user, address indexed asset, uint256 usdValue18, uint256 cpcMinted);
    event Redeemed(address indexed user, address indexed targetAsset, uint256 cpcBurned, uint256 usdOut18);
    event YieldAndFeesCompounded(uint256 addedUSD18, uint256 newNavUSD18);

    function currentNAV18() public view returns (uint256) {
        if (totalSupply == 0) return 1e18;
        return (totalReserveBasketUSD18 * 1e18) / totalSupply;
    }

    function depositAnyCurrency(address asset, uint256 amount) external returns (uint256 cpcOut) {
        require(amount > 0 && assetUSDPrice18[asset] > 0, "Invalid asset or amount");
        uint256 usdIn18 = (amount * assetUSDPrice18[asset]) / 1e18;
        uint256 nav = currentNAV18();
        cpcOut = (usdIn18 * 1e18) / nav;
        vaultAssetBalance[asset] += amount;
        totalReserveBasketUSD18 += usdIn18;
        totalSupply += cpcOut;
        balanceOf[msg.sender] += cpcOut;
        emit Deposited(msg.sender, asset, usdIn18, cpcOut);
    }

    function redeemAnyCurrency(address targetAsset, uint256 cpcAmount) external returns (uint256 assetOut) {
        require(balanceOf[msg.sender] >= cpcAmount && cpcAmount > 0, "Insufficient CPC");
        uint256 grossUSD18 = (cpcAmount * currentNAV18()) / 1e18;
        uint256 feeUSD18 = (grossUSD18 * SWAP_FEE_BPS) / 10000;
        uint256 netUSD18 = grossUSD18 - feeUSD18; // Fee stays inside totalReserveBasketUSD18 to boost NAV
        balanceOf[msg.sender] -= cpcAmount;
        totalSupply -= cpcAmount;
        totalReserveBasketUSD18 -= netUSD18;
        assetOut = (netUSD18 * 1e18) / assetUSDPrice18[targetAsset];
        require(vaultAssetBalance[targetAsset] >= assetOut, "Rebalance buffer");
        vaultAssetBalance[targetAsset] -= assetOut;
        emit Redeemed(msg.sender, targetAsset, cpcAmount, netUSD18);
    }

    /// @notice Compounds Lido wstETH, Beefy.com, Aerodrome AERO gauges, and Robinhood L2 yields into NAV
    function compoundExternalYield(uint256 yieldUSD18) external {
        totalReserveBasketUSD18 += yieldUSD18;
        emit YieldAndFeesCompounded(yieldUSD18, currentNAV18());
    }
}
