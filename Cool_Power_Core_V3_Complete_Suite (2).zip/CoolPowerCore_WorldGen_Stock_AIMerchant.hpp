#pragma once
#include <cstdint>
#include <array>

namespace cpc_engine_v3 {

struct SplitMix64 {
    uint64_t state;
    constexpr uint64_t next() noexcept {
        uint64_t z = (state += 0x9e3779b97f4a7c15ULL);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        return z ^ (z >> 31);
    }
    constexpr float next_signed_unit() noexcept {
        return (static_cast<float>(next() >> 40) / 8388608.0f) - 1.0f; // [-1.0, +1.0]
    }
};

enum class MerchantClass : uint8_t { GuildBroker=0, UtilityArb=1, AerodromeMM=2, RobinhoodDealer=3, FrontierQM=4 };

struct AIMerchantNPC {
    uint32_t id;
    MerchantClass role;
    float haggle_quirk;     // Bounded +/- 12%
    double daily_volume_usd;
    double fees_recycled_usd;
};

struct StockTickerMirror {
    char symbol[8];
    double live_price_usd;
    double day_change_pct;
};

struct WorldSectorV3 {
    int64_t sector_x, sector_y, sector_z;
    float terrain_variance; // Bounded +/- 14%
    float anomaly_boost;    // Bounded +/- 22%
    static constexpr float CPC_THERMAL_W_PER_CORE = 382.93f; // Fixed real physics
};

inline WorldSectorV3 generate_sector(uint64_t world_seed, int64_t sx, int64_t sy, int64_t sz) noexcept {
    SplitMix64 rng{world_seed ^ (uint64_t(sx) * 0x9E3779B185EBCA87ULL) ^ (uint64_t(sy) * 0xC2B2AE3D27D4EB4FULL) ^ uint64_t(sz)};
    return WorldSectorV3{sx, sy, sz, 1.0f + 0.14f * rng.next_signed_unit(), 1.0f + 0.22f * rng.next_signed_unit()};
}

} // namespace cpc_engine_v3
