COOL POWER CORE™ (CPC) — USPTO FILING FORMS & EXPANDED 100-USE-CASE SUITE
Inventor: Thomas Gabriel Coleman
Date: November 26, 2026

CONTENTS:
1. Cool_Power_Core_USPTO_Forms_and_100_Use_Cases.pdf
   - Pre-populated text templates for USPTO Form PTO/AIA/14 (ADS), PTO/AIA/01 (Inventor Oath),
     and PTO/SB/15A (Micro Entity Certification), plus Applications #51 through #100.
2. Cool_Power_Core_USPTO_Forms_and_100_Use_Cases.xlsx
   - Filterable Excel workbook containing Use Cases #51–#100 across heavy manufacturing,
     metallurgy, chemical processing, cold-chain, infrastructure, and extreme frontiers,
     paired with the 8-item USPTO Filing & Form Preparation Tracker.
3. Cool_Power_Core_USPTO_Forms_and_100_Use_Cases.md
   - Editable Markdown source for direct copy-paste into USPTO Patent Center forms and
     technical proposals.
