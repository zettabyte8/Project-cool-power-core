COOL POWER CORE (CPC) SANCTUARY CITY — RESIDENT HANDBOOK & GUILD CHARTER SUITE
Inventor & Architect: Thomas Gabriel Coleman
Date: November 26, 2026

INCLUDED FILES:
1. Cool_Power_Core_Resident_Handbook_and_Guild_Charter.pdf  (Print-ready 1-page Resident Handbook & Guild Charter)
2. Cool_Power_Core_Resident_Handbook_and_Guild_Charter.docx (Editable Microsoft Word Charter & Intake Form)
3. Cool_Power_Core_Resident_Handbook_and_Guild_Charter.md   (Clean Markdown Reference Document)
4. README.txt                                               (Package Index)
