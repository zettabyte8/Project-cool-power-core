COOL POWER CORE (CPC) — MARTIAN LAVA-TUBE METROPOLIS (#1,856), OCEANIC ARCHIPELAGO (#1,857) & MASTER 39-VOLUME DOSSIER
Inventor: Thomas Gabriel Coleman (Corona, California)
Date: November 26, 2026

INCLUDED FILES:
1. Cool_Power_Core_Mars_Ocean_and_Master_Dossier.pdf  - Print-ready landscape engineering blueprint (FIG. FR-1 & FIG. FR-2) and 39-volume master dossier.
2. Cool_Power_Core_Mars_Ocean_and_Master_Dossier.xlsx - Formula-driven 3-tab workbook (Mars & Ocean Metropolises, 39-Volume Program Rollup, 67-Claim Patent Portfolio).
3. Cool_Power_Core_Mars_Ocean_and_Master_Dossier.md   - Clean Markdown technical specification and executive synthesis.
4. README.txt                                         - Package manifest.
