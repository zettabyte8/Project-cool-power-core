COOL POWER CORE (CPC) - VOLUME XVIII (#851-#900) & NUCLEAR SMR BOTTOMING (#801)
Inventor: Thomas Gabriel Coleman
Governing Patents: CPC-PAT-2026-001 through 005-CIP (Claims 1-31 | FIGS. 1-11)

Included Deliverables:
1. Cool_Power_Core_Vol18_and_SMR_Bottoming.pdf  - Vector P&ID schematic, #801 SMR ROI model & Vol XVIII catalog
2. Cool_Power_Core_Vol18_and_SMR_Bottoming.xlsx - Interactive 3-tab workbook (Vol XVIII cases + SMR specs & energy balance)
3. Cool_Power_Core_Vol18_and_SMR_Bottoming.md   - Clean Markdown documentation
