COOL POWER CORE (CPC) — MASTER PATENT VOLUME v7 & APPALACHIAN 250K DEGRADED-LAND METROPOLIS
Inventor & Applicant: Thomas Gabriel Coleman (Corona, California, USA)
Master Docket: CPC-PAT-2026-001-MASTER-V7 / CPC-PCT-2026-001-WO
Date: November 26, 2026

CONTENTS:
1. Cool_Power_Core_Master_Patent_Volume_v7_and_Appalachia250K.pdf
   - Print-ready Master Patent Portfolio Volume v7 (Parent + CIP-2 through CIP-11 | 67 Claims | 23 Figures)
   - Complete PCT Rule 6.2(b) 67-Claim Set + Appalachian Strip-Mine 250,000-Resident Sanctuary City Blueprint
2. Cool_Power_Core_ePCT_Full_Application_v7.xml
   - Validated WIPO ST.36 v1.9 UTF-8 XML Application (Specification, All 67 Claims, Rule 8 Abstract) for ePCT Upload
3. Cool_Power_Core_Master_Patent_v7_and_Appalachia250K.xlsx
   - Interactive 3-Tab Workbook: Master_67_Claim_Docket, All_67_PCT_Rule6_Claims, and Appalachia_250K_Mine_Site
4. Cool_Power_Core_Master_Patent_Volume_v7.md
   - Clean Markdown Reference of Master Volume v7 and CPC-RIDGE-250K-APPALACHIA
5. README.txt
   - Package Manifest
