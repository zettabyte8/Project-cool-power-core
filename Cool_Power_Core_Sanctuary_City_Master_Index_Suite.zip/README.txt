COOL POWER CORE (CPC) — SANCTUARY CITY SERIES MASTER ARCHIVAL INDEX SUITE
Inventor & System Architect: Thomas Gabriel Coleman (Corona, California)
Date: November 26, 2026

INCLUDED FILES:
1. Cool_Power_Core_Sanctuary_City_Master_Index.pdf
   - Print-ready landscape executive index cataloging all 7 Sanctuary City modules (SC-01 to SC-07) and the 4-pillar Cool Power Core master program rollup.
2. Cool_Power_Core_Sanctuary_City_Master_Index.xlsx
   - Interactive two-tab Excel workbook indexing Modules SC-01 through SC-07 and the Unified Program Master Rollup.
3. Cool_Power_Core_Sanctuary_City_Master_Index.md
   - Clean, editable Markdown archival index and program compendium.
4. README.txt
   - This archive manifest.
