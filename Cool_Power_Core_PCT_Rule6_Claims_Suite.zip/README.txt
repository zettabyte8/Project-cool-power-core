COOL POWER CORE (CPC) — PCT RULE 6.2(b) 43-CLAIM & ePCT XML FILING SUITE
Docket: CPC-PCT-2026-001-WO
Applicant & Sole Inventor: Thomas Gabriel Coleman (Corona, California, USA)
Date: November 26, 2026

CONTENTS:
1. Cool_Power_Core_PCT_Rule6_Claims_43.pdf
   - Print-ready PCT Rule 11 formatted 43-claim set (13 independent + 30 dependent)
     with parenthetical reference numerals (100)-(1520) per PCT Rule 6.2(b) and
     complete Appendix A reference numeral concordance across FIGS. 1-15.
2. Cool_Power_Core_ePCT_Claims_43_Rule6.xml
   - WIPO ePCT / ST.36 structured XML claim file ready for direct electronic upload.
3. Cool_Power_Core_PCT_Rule6_Claims_and_XML_Map.xlsx
   - Two-tab Excel workbook indexing all 43 PCT claims and all 93 reference numerals.
4. Cool_Power_Core_PCT_Rule6_Claims_43.md
   - Clean Markdown master reference text.
