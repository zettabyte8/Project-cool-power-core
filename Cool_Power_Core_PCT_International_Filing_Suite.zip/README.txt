COOL POWER CORE (CPC) - PCT INTERNATIONAL PATENT & WIPO FEE-REDUCTION SUITE
Inventor & Applicant: Thomas Gabriel Coleman (Corona, California, USA)
Docket: CPC-PCT-2026-001-WO (Priority: CPC-PAT-2026-001 through 007-CIP | 43 Claims | 15 Figures)

Included Files:
1. Cool_Power_Core_PCT_International_Filing_Package.pdf  - Print-ready PCT/RO/101 Request summary, WIPO fee reduction schedule, Rule 8 Abstract, and 30-month national phase roadmap.
2. Cool_Power_Core_PCT_Filing_and_Global_Roadmap.xlsx    - Structured Excel workbook with PCT fee calculations, 15-jurisdiction national phase schedule, and PCT Rule 11 checklist.
3. Cool_Power_Core_PCT_International_Filing_Package.md   - Editable Markdown source documentation for patent counsel ePCT submission.
