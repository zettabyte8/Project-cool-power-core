COOL POWER CORE™ (CPC) — VOLUME XXIII DELIVERABLE SUITE
Inventor & Architect: Thomas Gabriel Coleman
Governing Patent Portfolio: CPC-PAT-2026-001 through 005-CIP (31 Claims | 11 Figures)

CONTENTS:
1. Cool_Power_Core_Vol23_Consumer_TinyHome_Emergency.pdf  - Landscape print-ready catalog (#1,101 - #1,150) & schematic
2. Cool_Power_Core_Vol23_Consumer_TinyHome_Emergency.xlsx - 3-tab interactive workbook (Vol XXIII, Sizing Matrix, 23-Vol Summary)
3. Cool_Power_Core_Vol23_Consumer_TinyHome_Emergency.md   - Clean Markdown technical reference & 50-case catalog
4. README.txt                                             - Package index
