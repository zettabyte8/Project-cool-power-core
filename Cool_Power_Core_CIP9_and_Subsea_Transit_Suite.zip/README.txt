COOL POWER CORE (CPC) — CIP-9 & TRANSOCEANIC SUBSEA TRANSIT SUITE
Inventor: Thomas Gabriel Coleman (Corona, California)
Date: November 26, 2026

CONTENTS:
1. Cool_Power_Core_CIP9_and_Subsea_Transit.pdf   - Print-ready specification, Seafloor Ecological Impact Model, Formal USPTO Drawings (FIGS. 18-19), & Claims 50-55
2. Cool_Power_Core_CIP9_and_Subsea_Transit.xlsx  - Interactive Excel model for Transoceanic Corridors, Seafloor Benthic Metrics, & Master 55-Claim Docket
3. Cool_Power_Core_CIP9_and_Subsea_Transit.md    - Clean Markdown technical & patent specification
4. README.txt                                    - Package index
