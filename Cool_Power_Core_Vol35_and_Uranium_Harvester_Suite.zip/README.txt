COOL POWER CORE (CPC) — VOLUME XXXV (#1,701 - #1,750) & SEAWATER URANIUM HARVESTER (#1,684)
Inventor & IP Owner: Thomas Gabriel Coleman
Master Patent Portfolio: CPC-PAT-2026-001 through 005-CIP (31 Claims | 11 Figures)

INCLUDED FILES:
1. Cool_Power_Core_Vol35_and_Uranium_Harvester.pdf  - Print-ready specification with P&ID schematic & Vol XXXV catalog
2. Cool_Power_Core_Vol35_and_Uranium_Harvester.xlsx - 3-tab formula-driven workbook (Uranium #1,684, Vol XXXV, 35-Vol Rollup)
3. Cool_Power_Core_Vol35_and_Uranium_Harvester.md   - Clean Markdown technical reference & 50-case catalog
