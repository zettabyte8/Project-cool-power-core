COOL POWER CORE (CPC) — LTA STRUCTURAL MASS BUDGET & OEM OUTREACH SUITE
Inventor: Thomas Gabriel Coleman

Included Files:
1. Cool_Power_Core_LTA_Structural_Mass_Budget.xlsx
   - Interactive spreadsheet calculating stratospheric composite envelope mass, helium aerostatic lift, CPC-LTA thermal lift trim, and square-cube payload scaling across 5 airship sizes.
2. Cool_Power_Core_OEM_Outreach_and_Briefing.md
   - Editable OEM partner outreach email template and one-page executive specification summary.
3. Cool_Power_Core_OEM_Briefing_and_LTA_Mass_Spec.pdf
   - Print-ready OEM executive tear-sheet and stratospheric composite airship mass specification.
