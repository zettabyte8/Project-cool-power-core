Cool Power Core (uCPC-ROBO) Multi-Frontier Autonomous Companion & Theater Simulation Suite
Inventor: Thomas Gabriel Coleman
