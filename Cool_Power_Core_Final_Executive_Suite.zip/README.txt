COOL POWER CORE (CPC) - FINAL EXECUTIVE & PROGRAM INDEX SUITE
Inventor / Architect: Thomas G. Coleman
Date: November 26, 2026

CONTENTS:
1. Cool_Power_Core_Master_Bibliography_and_Index.pdf - Print-ready master catalog of all 14 operational domains, engineering standards, and scientific principles.
2. Cool_Power_Core_Master_Bibliography_and_Index.md  - Editable Markdown reference of the complete program index and standards bibliography.
3. Cool_Power_Core_Executive_Board_Deck.pptx          - 5-slide Executive Board Presentation covering core physics, 14-sector versatility, USPTO IP portfolio, unit economics, and 2026-2031 roadmap.
