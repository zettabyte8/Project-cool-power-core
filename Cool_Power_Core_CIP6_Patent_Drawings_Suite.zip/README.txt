COOL POWER CORE (CPC) — CIP-6 FORMAL PATENT DRAWINGS SUITE
Inventor: Thomas Gabriel Coleman (Corona, California, USA)
Docket No.: CPC-PAT-2026-006-CIP (Continuation-in-Part of CPC-PAT-2026-001)

INCLUDED FILES:
1. Cool_Power_Core_CIP6_Patent_Drawings_FIG12_FIG13.pdf
   - Formal 37 CFR 1.84 black-and-white USPTO patent line art sheets (Sheets 6/7 & 7/7)
   - FIG. 12: Cross-sectional elevation of the CPC-SABER-MARS emitter & closed-loop hilt (1200-1224)
   - FIG. 13: Dual-bus power & <1.2 ms capacitive EVA deadman quench circuit (1300-1318)

2. Cool_Power_Core_CIP6_Patent_Drawings_FIG12_FIG13.md
   - Complete reference numeral concordance table and sheet specifications
