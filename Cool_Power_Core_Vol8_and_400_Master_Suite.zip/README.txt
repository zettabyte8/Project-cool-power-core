COOL POWER CORE (CPC) - VOLUME VIII (#351-#400) & 400-APPLICATION MASTER INDEX
Inventor: Thomas Gabriel Coleman
Contents:
1. Cool_Power_Core_Vol8_and_400_Master_Index.pdf  - Print-ready landscape catalog & 400-case master index
2. Cool_Power_Core_Vol8_and_400_Master_Index.xlsx - Filterable 3-tab spreadsheet (Vol. VIII, Rollup, Cluster Index)
3. Cool_Power_Core_Vol8_and_400_Master_Index.md   - Clean Markdown reference document
