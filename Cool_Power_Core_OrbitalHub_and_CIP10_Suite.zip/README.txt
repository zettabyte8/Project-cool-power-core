COOL POWER CORE™ (CPC) — ORBITAL ARTISANAL SPACE COLONY & USPTO CIP-10 SUITE
Inventor: Thomas Gabriel Coleman (Corona, California, USA)
Date: November 26, 2026

INCLUDED DELIVERABLES:
1. Cool_Power_Core_OrbitalHub_and_CIP10.pdf         - Print-ready engineering blueprint, energy/water/O2 balance, Claims 56-61 & FIGS. 20-21.
2. Cool_Power_Core_OrbitalHub_and_CIP10.xlsx        - Formula-driven Excel workbook comparing Orbital Colony & Ocean Sanctuary Hub + 61-Claim Docket.
3. Cool_Power_Core_OrbitalHub_and_CIP10.md          - Complete Markdown engineering specification, patent claims & figure concordance.
4. Cool_Power_Core_ePCT_Claims_56_to_61_v6.xml      - WIPO ST.36 structured UTF-8 XML claim append file (PCT Rule 6.2(b)).
5. README.txt                                       - Package manifest and index.
