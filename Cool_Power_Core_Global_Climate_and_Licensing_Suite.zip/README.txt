COOL POWER CORE (CPC) - GLOBAL CLIMATE & FIELD-OF-USE IP LICENSING SUITE
Inventor & Principal Architect: Thomas Gabriel Coleman

Included Files:
1. Cool_Power_Core_Global_Climate_and_Licensing_Whitepaper.pdf  - Print-ready executive whitepaper & vector system diagram
2. Cool_Power_Core_Field_of_Use_Licensing_Model.xlsx           - Interactive 6-sector OEM royalty & planetary impact workbook
3. Cool_Power_Core_Global_Climate_and_Commercial_Model.md      - Editable Markdown technical & licensing reference
