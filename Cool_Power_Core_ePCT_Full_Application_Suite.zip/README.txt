COOL POWER CORE (CPC) - COMPLETE WIPO ePCT FULL APPLICATION XML SUITE
Inventor & Applicant: Thomas Gabriel Coleman (Corona, CA, USA)
Docket: CPC-PCT-2026-001-WO | Date: November 26, 2026

INCLUDED FILES:
1. Cool_Power_Core_ePCT_Full_Application.xml       - WIPO ST.36 v1.9 XML (Description [0001]-[0024], 43 Rule 6.2(b) Claims, Rule 8 Abstract)
2. Cool_Power_Core_ePCT_Full_Application_Summary.pdf - Print-ready ePCT XML Audit & Abstract Summary Sheet
3. Cool_Power_Core_ePCT_Full_Application_Index.xlsx  - Excel XML Compliance Audit & 43-Claim Verification Table
4. Cool_Power_Core_ePCT_Full_Application_Guide.md    - Markdown Reference & Step-by-Step ePCT / Patent Center Upload Guide
