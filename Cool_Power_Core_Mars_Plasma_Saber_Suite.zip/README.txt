Cool Power Core (CPC-SABER-MARS) Handheld Plasma Lightsaber / Lance Suite
Inventor: Thomas Gabriel Coleman
Contents:
1. Cool_Power_Core_Mars_Plasma_Saber_Spec.pdf - Print-ready specification & schematic
2. Cool_Power_Core_Mars_Plasma_Saber_Model.xlsx - Duty-cycle energy balance & hilt BOM
3. Cool_Power_Core_Mars_Plasma_Saber_Model.md - Editable Markdown engineering report
