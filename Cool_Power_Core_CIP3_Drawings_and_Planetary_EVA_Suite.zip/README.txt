COOL POWER CORE™ — USPTO CIP-3 DRAWINGS & PLANETARY EVA EXOSKELETON SUITE
Inventor: Thomas Gabriel Coleman

Contents:
1. Cool_Power_Core_CIP3_Patent_Drawings_FIG6_FIG7.pdf : Formal B&W USPTO patent sheets (FIG. 6 LCG/ECLSS loop & FIG. 7 10-axis QDD bus)
2. Cool_Power_Core_Planetary_EVA_Exoskeleton_Spec.pdf : Print-ready Lunar & Martian planetary EVA exoskeleton specification
3. Cool_Power_Core_Planetary_EVA_Exoskeleton.xlsx     : Formula-driven mission endurance, mass, and energy balance workbook
4. Cool_Power_Core_Planetary_EVA_Exoskeleton_Model.md : Clean Markdown technical documentation
