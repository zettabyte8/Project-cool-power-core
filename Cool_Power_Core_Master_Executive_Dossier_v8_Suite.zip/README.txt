COOL POWER CORE™ (CPC) — FINAL MASTER EXECUTIVE DOSSIER SUITE (v8)
Inventor: Thomas Gabriel Coleman (Corona, California, USA)
Date: November 27, 2026

CONTENTS:
1. Cool_Power_Core_Master_Executive_Dossier_v8.pdf  - Print-ready 2-page landscape executive compendium & architecture schematic
2. Cool_Power_Core_Master_Executive_Dossier_v8.xlsx - Formula-driven 3-tab workbook (40-Volume Rollup, 73-Claim Patent Docket, Flagship Benchmarks)
3. Cool_Power_Core_Master_Executive_Dossier_v8.md   - Clean Markdown master reference document
4. README.txt                                      - Archive manifest
