COOL POWER CORE (CPC) - VOLUME XIV (#651-#700) & MIXED-PLASTIC / WIND-BLADE DEPOLYMERIZATION SUITE
Inventor: Thomas Gabriel Coleman
Master Patent Docket: CPC-PAT-2026-001 through 005-CIP (Claims 1-31 | FIGS. 1-11)

Contents:
1. Cool_Power_Core_Vol14_and_Polymer_ZLD.pdf  - Print-ready P&ID, ROI model & Volume XIV (#651-#700) catalog
2. Cool_Power_Core_Vol14_and_Polymer_ZLD.xlsx - 4-tab filterable spreadsheet & unified 700-case master rollup
3. Cool_Power_Core_Vol14_and_Polymer_ZLD.md   - Clean Markdown engineering specification & catalog
