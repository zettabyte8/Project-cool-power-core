COOL POWER CORE (CPC) — COMPLETE CONSOLIDATED PATENT PORTFOLIO VOLUME (v2)
Inventor: Thomas Gabriel Coleman
Date: November 26, 2026

CONTENTS:
1. Cool_Power_Core_Master_Patent_Portfolio_Volume_v2.pdf
   - Filing-ready USPTO Master Patent Volume consolidating Parent Utility (CPC-PAT-2026-001)
     and Continuations-in-Part CIP-2 through CIP-5 (Claims 1-31 | Formal Drawing Sheets FIGS. 1-11).
2. Cool_Power_Core_Master_Patent_Portfolio_Volume_v2.md
   - Clean Markdown source of the Abstract, Docket Index, and all 31 Patent Claims.
