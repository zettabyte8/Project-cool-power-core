COOL POWER CORE (CPC-EXO-EXT-II) FULL-BODY EXOSKELETON & PTO SUITE
Inventor: Thomas Gabriel Coleman

Contents:
1. Cool_Power_Core_Full_Exo_PTO_and_BOM.pdf  - Print-ready engineering spec, FIG. EXO-II schematic, BOM & control architecture
2. Cool_Power_Core_Full_Exo_BOM_and_Control.xlsx - Formula-structured 32-SKU Prototype BOM & 10-DOF Joint Control workbook
3. Cool_Power_Core_Full_Exo_PTO_and_BOM.md   - Complete Markdown engineering specification
