COOL POWER CORE (CPC): HORIZONS UNBOUND — BRANDED PLAYABLE BUILD
Invented & Architected by: Thomas Gabriel Coleman (Corona, CA)

INCLUDED FILES:
1. Cool_Power_Core_Horizons_Playable_Browser_Game.html : 60 FPS cross-device browser game with animated header logo, SVG favicon, and live canvas emblem
2. Cool_Power_Core_Brand_Logo.svg : Standalone 512x512 vector brand mark
3. Cool_Power_Core_Logo_Integration_Guide.md : Brand geometry and UI integration documentation
