COOL POWER CORE™ (CPC) — CIP-11 (CLAIMS 62–67 | FIGS. 22–23) & MOJAVE 250K BROWNFIELD SITE SUITE
Inventor: Thomas Gabriel Coleman (Corona, California)
Docket: CPC-PAT-2026-011-CIP | PCT Priority: CPC-PCT-2026-001-WO

INCLUDED FILES:
1. Cool_Power_Core_CIP11_and_Mojave250K_Site.pdf   - Print-ready CIP-11 specification, Claims 62-67, FIGS. 22-23 drawings, & Mojave 250K site masterplan
2. Cool_Power_Core_CIP11_and_Mojave250K_Site.xlsx  - Formula-driven workbook: Master 67-Claim Docket, Mojave 250K Brownfield Model, & FIGS. 22-23 Concordance
3. Cool_Power_Core_CIP11_and_Mojave250K_Site.md    - Editable Markdown specification, claims, and site engineering parameters
4. Cool_Power_Core_ePCT_Claims_62_to_67_v7.xml     - Validated WIPO ST.36 XML claim append file (PCT Rule 6.2(b) parenthetical numerals)
5. README.txt                                      - Archive manifest
