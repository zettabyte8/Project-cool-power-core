COOL POWER CORE™ (CPC) — ARID/ARCTIC 250K CITIES & 1,855-CASE COMPENDIUM SUITE
Inventor: Thomas Gabriel Coleman (Corona, California)
Date: November 26, 2026

INCLUDED FILES:
1. Cool_Power_Core_Arid_Arctic_250K_and_Master_1855.pdf
   - Print-ready engineering blueprint for Hyper-Arid Desert (CPC-RIDGE-250K-ARID) and Arctic Permafrost (CPC-RIDGE-250K-ARCTIC) 250,000-resident cities plus the 38-volume 1,855-case portfolio rollup.
2. Cool_Power_Core_Arid_Arctic_250K_and_Master_1855.xlsx
   - Searchable 1,855-row Excel database (CPC-0001 through CPC-1855), 38-volume summary rollup, and 4-site degraded-land 250K city comparison matrix.
3. Cool_Power_Core_Arid_Arctic_250K_and_Master_1855.md
   - Clean Markdown technical specification and master index.
