COOL POWER CORE (CPC-EXO-EXT-II) — EMBEDDED FIRMWARE & PATENT CIP SUITE
Inventor: Thomas Gabriel Coleman
Date: November 26, 2026

Contents:
1. Cool_Power_Core_Exo_Firmware_CortexM7.c  - Ready-to-compile C source for 10-axis QDD admittance/regen & 100 Hz dual-uCPC/ECLSS supervisor
2. Cool_Power_Core_Exo_Suit_Patent_CIP.md   - USPTO Continuation-in-Part (CPC-PAT-2026-003-CIP) specification & Claims 14-19
3. Cool_Power_Core_Exo_Firmware_and_Patent_CIP.pdf - Print-ready combined firmware architecture & patent CIP document
