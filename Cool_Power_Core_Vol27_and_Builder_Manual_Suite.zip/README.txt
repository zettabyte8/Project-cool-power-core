COOL POWER CORE (CPC) — VOLUME XXVII & BUILDER ROUGH-IN SUITE
Inventor & IP Owner: Thomas Gabriel Coleman
Master Patent Portfolio: CPC-PAT-2026-001 through 005-CIP (31 Claims | 11 Figures)
Cumulative Milestone: 1,350 Validated Applications (#0001 - #1,350)

INCLUDED FILES:
1. Cool_Power_Core_Vol27_and_Builder_Manual.pdf  - Print-ready landscape builder CAD rough-in manual + Volume XXVII catalog (#1,301 - #1,350).
2. Cool_Power_Core_Vol27_and_Builder_Manual.xlsx - Interactive 3-tab workbook (Builder_RoughIn_Specs, Vol_XXVII_1301_to_1350, Cumulative_1350_Rollup).
3. Cool_Power_Core_Vol27_and_Builder_Manual.md   - Clean Markdown engineering specification and 50-case catalog.
