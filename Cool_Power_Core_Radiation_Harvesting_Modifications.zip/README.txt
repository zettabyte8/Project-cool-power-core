COOL POWER CORE (CPC-RAD-HV) — NUCLEAR REMEDIATION & RADIATION HARVESTING ARCHIVE
Inventor: Thomas G. Coleman

Included Files:
1. Cool_Power_Core_Radiation_Harvesting_Modifications.md
   - Full engineering report detailing the 7 hardware modifications (MOD-R01 to MOD-R07) enabling direct betavoltaic, gamma-voltaic, and radiolytic energy harvesting while cleaning radioactive water and leachate.
2. Cool_Power_Core_Fukushima_Rad_Harvest_Spec.pdf
   - Print-ready specification with closed-loop vector process schematic (FIG. R-HV1), rad-hardening ratings (10^8 Gy), and Fukushima multi-zone projections.
3. Cool_Power_Core_Fukushima_Rad_Harvest_Model.xlsx
   - Interactive 3-tab Excel workbook containing Fukushima site deployment sizing, single-core radiation-harvesting energy balance (+364.5 W/core), and modification delta BOM (+$775/core).
