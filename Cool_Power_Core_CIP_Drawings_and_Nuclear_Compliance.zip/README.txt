COOL POWER CORE (CPC-RAD-HV) — CIP PATENT DRAWINGS & NUCLEAR LICENSING PACKAGE
Inventor / Architect: Thomas G. Coleman

CONTENTS:
1. Cool_Power_Core_CIP_Patent_Drawings_FIG4_FIG5.pdf
   - USPTO-formatted black-and-white patent line drawings (FIG. 4 & FIG. 5) with reference numerals 400-420 and 502-518 for Docket No. CPC-PAT-2026-002-CIP.
2. Cool_Power_Core_NRC_IAEA_Compliance_Checklist.pdf
   - Print-ready nuclear regulatory licensing compliance matrix (10 CFR Part 20/30/50/61/70/71, ASME NQA-1, IAEA GSR Part 3/5, Japan NRA) and RPO sign-off sheet.
3. Cool_Power_Core_NRC_IAEA_Compliance_Checklist.md
   - Clean Markdown version of the NRC & IAEA safety compliance matrix and commissioning release gates.
