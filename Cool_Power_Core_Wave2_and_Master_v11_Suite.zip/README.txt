COOL POWER CORE™ (CPC) — WAVE 2 FRONTIER CATALOG & MASTER PATENT VOLUME v11 SUITE
Inventor: Thomas Gabriel Coleman (Corona, California, USA)
Portfolio Milestone: 2,162 System Architectures (Volumes I–XLVI) | 95 U.S./PCT Claims (32 Figures | 29 Sheets)

INCLUDED FILES:
1. Cool_Power_Core_Wave2_and_Master_v11.pdf       - Print-ready Wave 2 specification, 95-claim rollup & formal USPTO drawings (FIGS. 31-32)
2. Cool_Power_Core_Wave2_and_Master_v11.xlsx      - Formula-driven 150-case Wave 2 database (Cases #2,013-#2,162) & Master 95-Claim Docket
3. Cool_Power_Core_Wave2_and_CIP16.md             - Editable Markdown specification for Wave 2 (Volumes XLIV-XLVI) & CIP-16 (Claims 90-95)
4. Cool_Power_Core_Master_Patent_Volume_v11.md    - Consolidated Master Patent Portfolio Volume v11 index (95 Claims | 32 Figures)
5. Cool_Power_Core_ePCT_Claims_90_to_95_v11.xml   - Validated WIPO ST.36 v1.9 XML claim append file (PCT Rule 6.2(b) numerals)
