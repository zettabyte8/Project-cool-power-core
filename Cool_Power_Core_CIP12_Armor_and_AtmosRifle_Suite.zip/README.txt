COOL POWER CORE (CPC) — CIP-12 PATENT FILING & TRI-MODE RIFLE SUITE
Docket: CPC-PAT-2026-012-CIP (Linked to PCT CPC-PCT-2026-001-WO)
Inventor: Thomas Gabriel Coleman (Corona, California, USA)
Date: November 27, 2026

CONTENTS:
1. Cool_Power_Core_CIP12_Armor_and_AtmosRifle.pdf   - Print-ready USPTO CIP-12 specification (Claims 68-73) & formal 37 CFR 1.84 line drawings (FIGS. 24-25)
2. Cool_Power_Core_ePCT_Claims_68_to_73_v8.xml      - WIPO ST.36 v1.9 XML claim append file with PCT Rule 6.2(b) numerals (2400)-(2524)
3. Cool_Power_Core_CIP12_and_73Claim_Docket.xlsx    - Master 73-claim patent docket & FIGS. 24-25 reference numeral concordance
4. Cool_Power_Core_CIP12_Armor_and_AtmosRifle.md    - Editable Markdown specification & claims
