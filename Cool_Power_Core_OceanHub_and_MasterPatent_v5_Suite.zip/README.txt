COOL POWER CORE™ (CPC) — FLOATING OCEAN SANCTUARY HUB & MASTER PATENT VOLUME v5 SUITE
Inventor: Thomas Gabriel Coleman (Corona, CA)
Date: November 26, 2026

INCLUDED FILES:
1. Cool_Power_Core_OceanHub_and_MasterPatent_v5.pdf
   - Print-ready landscape engineering specification & vector architecture diagram (FIG. OH-1) for the 2,500-resident Floating Ocean Sanctuary City & Submerged Transoceanic Maglev Hub (CPC-CITY-OCEAN-HUB), paired with the consolidated 55-Claim / 19-Figure Master Patent Volume v5 docket matrix.
2. Cool_Power_Core_OceanHub_and_MasterPatent_v5.xlsx
   - Formula-driven 3-tab Excel workbook modeling the 12,500-core energy/water/mineral balance (+4,234.9 kWe, 185,080 L/day pure water, 3,660.5 kg/day zero-brine minerals), 10-year hub financial model (4.66-yr payback), and complete 55-claim USPTO/PCT concordance.
3. Cool_Power_Core_OceanHub_and_MasterPatent_v5.md
   - Clean Markdown technical specification and Master Patent Volume v5 index.
4. Cool_Power_Core_ePCT_Claims_44_to_55_v5.xml
   - Structured WIPO ST.36 v1.9 UTF-8 XML file appending Claims 44–55 (CIP-7 & CIP-8) with PCT Rule 6.2(b) parenthetical reference numerals (1600)–(1918) for direct ePCT / USPTO Patent Center upload.
