COOL POWER CORE (CPC) - CIP-14 PATENT PACKAGE (CLAIMS 78-83 | FIGS. 27-28)
Inventor: Thomas Gabriel Coleman (Corona, California, USA)
Date: November 27, 2026

FILES INCLUDED:
1. Cool_Power_Core_CIP14_Suit_and_OctoEXO.pdf        - Print-ready USPTO CIP-14 Specification, Claims 78-83, and Formal B&W Line Drawings (FIGS. 27-28, Sheets 24/25 & 25/25)
2. Cool_Power_Core_ePCT_Claims_78_to_83_v10.xml      - WIPO ST.36 v1.9 Structured XML Claim Append File (PCT Rule 6.2(b))
3. Cool_Power_Core_CIP14_and_83Claim_Docket.xlsx     - Master 83-Claim Docket & Reference Numeral Concordance (2700-2818)
4. Cool_Power_Core_CIP14_Suit_and_OctoEXO.md         - Editable Markdown Specification & Claims Source
