COOL POWER CORE™ (CPC) — VOLUME XIX (#901-#950) & 900-APPLICATION MASTER INDEX SUITE
Inventor & System Architect: Thomas Gabriel Coleman
Master Patent Portfolio: CPC-PAT-2026-001 through 005-CIP (31 Claims | 11 Formal Figures)

INCLUDED FILES:
1. Cool_Power_Core_Vol19_and_900_Master_Index.pdf  - Print-ready landscape specification & catalog
2. Cool_Power_Core_Vol19_and_900_Master_Index.xlsx - Filterable 3-tab Excel master database
3. Cool_Power_Core_Vol19_and_900_Master_Index.md   - Clean Markdown documentation source
