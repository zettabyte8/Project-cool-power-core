COOL POWER CORE (CPC-LTA) & OEM LICENSING SUITE
Inventor: Thomas Gabriel Coleman
=================================================
1. Cool_Power_Core_NDA_and_License_Term_Sheet.docx
   - Editable Mutual NDA & Field-of-Use License Term Sheet for OEM partners.
2. Cool_Power_Core_LTA_Stratospheric_Specification.pdf
   - Print-ready engineering spec & schematic (FIG. LTA-1) for 20 km LTA composite airships.
3. Cool_Power_Core_LTA_Stratospheric_Model.xlsx
   - Formula-driven spreadsheet modeling 5 LTA airship platforms & single-core energy/buoyancy balance.
4. Cool_Power_Core_LTA_and_Licensing_Overview.md
   - Clean Markdown technical & licensing summary.
