COOL POWER CORE: HORIZONS UNBOUND & CPC-COIN ARCHIVE
Inventor: Thomas Gabriel Coleman (Corona, California)
Contents:
1. Cool_Power_Core_Infinite_Game_and_CPC_Coin.md   - Full C++20 engine, educational curriculum, & Solidity CPC-COIN spec
2. Cool_Power_Core_Infinite_Game_and_CPC_Coin.pdf  - Print-ready landscape blueprint & CPC-COIN yield architecture
3. Cool_Power_Core_Infinite_Game_and_CPC_Coin.xlsx - 5-Year NAV compounding & 60 FPS frame-budget workbook
