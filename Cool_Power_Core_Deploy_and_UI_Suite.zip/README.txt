COOL POWER CORE™ (CPC-COIN v5.0) — DEPLOYMENT & INTERACTIVE AGORA KIOSK SUITE
Inventor & Architect: Thomas Gabriel Coleman (Corona, CA)

Included Files:
1. deploy_and_verify_v5.js            - Hardhat multi-chain deployment & Basescan verification script
2. Cool_Power_Core_Agora_Kiosk_UI.html - Interactive HTML5 Sanctuary Agora Kiosk & Stock Exchange UI
3. Cool_Power_Core_Deploy_and_UI_Guide.md - Hardhat & Foundry CLI deployment guide
4. Cool_Power_Core_Deploy_and_UI_Spec.pdf  - Print-ready landscape specification & checklist
