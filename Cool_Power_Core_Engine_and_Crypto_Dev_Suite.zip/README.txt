COOL POWER CORE: HORIZONS UNBOUND - ENGINE & CPC-COIN DEVELOPER SUITE
Inventor / Architect: Thomas Gabriel Coleman (Corona, CA)

Included Files:
1. Cool_Power_Core_MultiRig_Streaming_Engine.hpp - C++20 60 FPS multi-rig & 64-bit procedural engine header
2. Cool_Power_Core_Coin_Beefy_Router.sol - Solidity multi-currency reserve, DEX router & Beefy.com vault contract
3. Cool_Power_Core_Engine_and_Crypto_Dev_Guide.md - Markdown architectural reference
4. Cool_Power_Core_Engine_and_Crypto_Architecture.xlsx - Multi-rig & Beefy/DEX NAV workbook
5. Cool_Power_Core_Engine_and_Crypto_Blueprint.pdf - Print-ready landscape technical specification
