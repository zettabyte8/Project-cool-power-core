COOL POWER CORE (uCPC-SUIT) EXTREME ENVIRONMENT LIFE-SUPPORT SUIT SUITE
Inventor & Architect: Thomas Gabriel Coleman
========================================================================
Included Files:
1. Cool_Power_Core_Extreme_Suit_Specification.pdf
   - Print-ready engineering specification with closed-loop metabolic recycling schematic (FIG. S-1).
2. Cool_Power_Core_Extreme_Suit_Model.xlsx
   - Interactive Excel workbook with Suit_Variant_Comparison and Metabolic_Energy_Mass_Balance tabs.
3. Cool_Power_Core_Extreme_Environment_Suit_Model.md
   - Complete Markdown engineering report covering 6,000 m abyssal, deep-space EVA, and CBRN/polar suits.
