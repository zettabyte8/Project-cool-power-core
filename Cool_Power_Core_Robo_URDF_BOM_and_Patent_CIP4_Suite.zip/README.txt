COOL POWER CORE (uCPC-ROBO) — URDF KINEMATICS, BOM & PATENT CIP-4 SUITE
Inventor: Thomas Gabriel Coleman | Docket: CPC-PAT-2026-004-CIP

Contents:
1. cpc_robo_biomimetic_companion.urdf
   - ROS 2 / Gazebo / NVIDIA Isaac Sim URDF kinematic model for configurable
     quadruped hound, feline scout, and winged biomimetic dragon chassis.
2. Cool_Power_Core_Robo_BOM_and_Kinematics.xlsx
   - 14-SKU prototype Bill of Materials ($31,710.00 prototype / $8,450 volume)
     and 19/21-DOF QDD actuator torque, velocity, and waste-heat schedule.
3. Cool_Power_Core_Robo_Companion_Patent_CIP.md
   - Full USPTO Continuation-in-Part specification paragraphs [0085]-[0088] and
     formal Claims 20-25 in editable Markdown.
4. Cool_Power_Core_Robo_URDF_BOM_and_Patent_CIP4.pdf
   - Print-ready engineering & patent specification combining all sections.
