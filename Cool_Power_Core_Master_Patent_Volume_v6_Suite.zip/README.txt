COOL POWER CORE (CPC) — MASTER PATENT PORTFOLIO VOLUME v6 SUITE
Inventor: Thomas Gabriel Coleman (Corona, California, USA)
Master U.S. Dockets: CPC-PAT-2026-001 through CPC-PAT-2026-010-CIP (10 Filings)
International PCT Docket: CPC-PCT-2026-001-WO (WIPO ST.36 v1.9 / PCT Rule 6.2(b))
Scope: 61 Claims (18 Independent + 43 Dependent) | 21 Formal Figures (FIGS. 1-21, 16 Sheets)
Date: November 26, 2026

INCLUDED FILES:
1. Cool_Power_Core_Master_Patent_Volume_v6.pdf
   - Print-ready Master Patent Portfolio Volume v6 containing the 10-filing priority table,
     unified architecture schematic, and all 61 PCT Rule 6.2(b) claims.
2. Cool_Power_Core_ePCT_Full_Application_v6.xml
   - Validated UTF-8 WIPO ST.36 v1.9 XML application encoding bibliographic metadata, all 10
     U.S. priority claims, specification summary, all 61 claims, and the Rule 8 abstract.
3. Cool_Power_Core_Master_Patent_v6_61Claims.xlsx
   - Multi-tab Excel docket & claim concordance workbook (Master_61_Claim_Docket,
     All_61_PCT_Rule6_Claims, Portfolio_Audit_Summary).
4. Cool_Power_Core_Master_Patent_Volume_v6.md
   - Clean editable Markdown master patent volume (specification summary + all 61 claims).
5. Cool_Power_Core_Master_Patent_Volume_v6_Suite.zip
   - Consolidated ZIP archive bundling all files above plus this README.txt manifest.
