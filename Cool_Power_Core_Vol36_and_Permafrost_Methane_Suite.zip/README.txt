COOL POWER CORE (CPC) — VOLUME XXXVI & PERMAFROST METHANE OXIDIZER SUITE
Inventor & IP Holder: Thomas Gabriel Coleman
Master Patent Portfolio: CPC-PAT-2026-001 through 005-CIP (Claims 1-31 | FIGS. 1-11)
Milestone: 1,800 Validated Applications (#0001 - #1,800)

Included Files:
1. Cool_Power_Core_Vol36_and_Permafrost_Methane.pdf  - Print-ready landscape specification with vector P&ID schematic & Vol XXXVI catalog
2. Cool_Power_Core_Vol36_and_Permafrost_Methane.xlsx - Formula-driven 4-tab Excel workbook (Energy Balance, Arctic Barge ROI, Vol XXXVI, 1,800-Case Rollup)
3. Cool_Power_Core_Vol36_and_Permafrost_Methane.md   - Clean Markdown technical model & 50-application catalog
