# Cool Power Core — Prototype Commissioning & Bench-Test SOP (`CPC-PROTO-001`)

## Critical Hardware Safety Interlocks (Sub-10 us CPLD Trip)
- **N52H Magnet Over-Temperature (`AI-01`):** Trip > 95 C (Hard shutdown at 105 C to protect N52H magnets)
- **Air Bearing Supply Pressure (`AI-02`):** Trip < 4.5 bar (Prevents 5 micron bearing touchdown)
- **33.6 kV Plasma Over-Current (`AI-03`):** Trip > 0.75 mA average (> 25 W primary draw)
- **Reservoir Temperature Hold (`AI-04`):** Target 90.0 +/- 1.5 C before enabling cavitation injection

## 12-Step Sequential Verification Protocol
1. **TST-01:** Verify 5.0 micron air bearing float clearance at 5.5 bar dry nitrogen/air supply.
2. **TST-02:** Leak-check 8YSZ liner and vacuum-brazed Si3N4/Inconel 718 piston crowns to 45 bar static.
3. **TST-03:** Confirm argon aerogel thermal jacket integrity and verify < 85 C magnet housing temp under heater soak.
4. **TST-04:** Verify 4-layer ECU galvanic isolation (45 mm air clearance / 65 mm PTFE creepage to 33.6 kV stage).
5. **TST-05:** Calibrate 1 kHz PID loops (Reservoir temp, Intake humidity RH%, Exhaust split VGT, 50 Hz phase lock).
6. **TST-06:** Pre-heat reservoir to 90 C using simulated exhaust thermal loop (43.9 W offset verified).
7. **TST-07:** Engage graphene fluidic vortex amplifier and 40 kHz PZT cavitator at 18.5 W; confirm cold steam mist.
8. **TST-08:** Enable 4.2 V / 20 W ZVS driver and verify 33.6 kV corona/O3 discharge across tungsten arc gap.
9. **TST-09:** Ramp opposed-piston linear alternator to 50 Hz synchronous resonance (30:1 compression ratio).
10. **TST-10:** Verify dual-bus rectification across linear alternators, micro Tesla turbine, TEG/pyroelectric, PZT, and ion grid.
11. **TST-11:** Validate V2O5/TiO2 SCR honeycomb NOx/O3 slip (< 50 ppb O3 at exhaust outlet) and condenser water recovery.
12. **TST-12:** Execute 24-hour continuous endurance burn-in and log net electrical, water, and thermal efficiency KPIs.
