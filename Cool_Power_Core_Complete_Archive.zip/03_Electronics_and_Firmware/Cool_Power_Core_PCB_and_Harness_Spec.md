# Cool Power Core — 4-Layer PCB Layout & Dual-Bus Harness Specification
- **PCB Stackup (IPC-2221B):** Layer 1 (Signals & Fiber-Optic TX/RX) | Layer 2 (Solid GND Plane) | Layer 3 (48V / 12V / 4.2V / 3.3V Split Power) | Layer 4 (Low-Speed Sensor Return)
- **High-Voltage Isolation (33.6 kV Cockcroft-Walton Stage):** Off-board epoxy-potted HV module driven via 8 mm galvanic moat + plastic optical fiber (POF) ZVS gate trigger; minimum **45 mm air clearance** and **65 mm PTFE creepage** to any 15 W ECU trace.
- **Harness Connectors:** `J1` Dual Linear Alternator 3-Phase Rectifier Input | `J2` Micro Tesla/VGT & TEG/Pyro/PZT Harvester Bus | `J3` 4.2V/20W ZVS Fiber-Optic & Power Feed | `J4` Fluidic Vortex Proportional Valves | `J5` PT1000 & Ion Grid Telemetry | `J6` 48V/12V Regulated Output Bus.
