/* Cool Power Core (CPC-PROTO-001) - 15W ARM Cortex-M7 Real-Time Control Reference */
#include <stdint.h>
#include <stdbool.h>

typedef enum {
    STATE_S0_BOOT_SELF_TEST = 0,
    STATE_S1_AIR_BEARING_FLOAT,
    STATE_S2_THERMAL_PREHEAT_90C,
    STATE_S3_CAVITATION_PLASMA_IGNITE,
    STATE_S4_50HZ_CLOSED_LOOP_RUN,
    STATE_S5_FAULT_SAFE_SHUTDOWN
} cpc_state_t;

typedef struct {
    float kp, ki, kd;
    float integral;
    float prev_error;
    float out_min, out_max;
} pid_ctrl_t;

float pid_update(pid_ctrl_t *pid, float setpoint, float measurement, float dt) {
    float err = setpoint - measurement;
    pid->integral += err * dt;
    if (pid->integral > pid->out_max) pid->integral = pid->out_max;
    if (pid->integral < pid->out_min) pid->integral = pid->out_min;
    float deriv = (err - pid->prev_error) / dt;
    pid->prev_error = err;
    float out = (pid->kp * err) + (pid->ki * pid->integral) + (pid->kd * deriv);
    if (out > pid->out_max) out = pid->out_max;
    if (out < pid->out_min) out = pid->out_min;
    return out;
}

bool check_hardware_interlocks(float magnet_temp_c, float bearing_bar, float plasma_watts) {
    if (magnet_temp_c > 95.0f) return false;   /* Protect N52H magnets (<120C limit) */
    if (bearing_bar < 4.5f)    return false;   /* Protect 5-micron air bearings */
    if (plasma_watts > 22.0f)  return false;   /* Enforce 20W ZVS plasma envelope */
    return true;
}
