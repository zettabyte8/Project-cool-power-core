# Cool Power Core — Complete Engineering, Hardware, ROI & IP Archive
**Inventor / Designer:** Thomas G. Coleman  
**System ID:** CPC-PROTO-001 | **Patent Docket:** CPC-PAT-2026-001

## Archive Contents
1. `01_System_Summary_and_Thermodynamics/`
   - `Cool_Power_Core_Master_Summary.md` — Complete thermodynamic, electrical, marine ROI, and mass-balance reference
2. `02_Prototype_BOM_and_Testing/`
   - `Cool_Power_Core_Prototype_BOM.csv` — 24-SKU prototype Bill of Materials ($6,215.00 unit prototype cost)
   - `Cool_Power_Core_Bench_Test_SOP.md` — 12-step commissioning checklist and ECU hardware trip limits
3. `03_Electronics_and_Firmware/`
   - `Cool_Power_Core_ECU_Firmware_Reference.c` — Real-time ARM Cortex-M7 FSM, 1 kHz PID control loops, and CPLD safety trips
   - `Cool_Power_Core_PCB_and_Harness_Spec.md` — 4-layer IPC-2221B PCB stackup, 45 mm / 65 mm 33.6 kV clearance rules, and J1–J7 pinouts
4. `04_Patent_Filing_Package/`
   - `Cool_Power_Core_Complete_Patent_Filing.md` — Full USPTO-formatted specification (paragraphs [0001]–[0024]), FIG. 1–3 descriptions, and 7 formal claims
