COOL POWER CORE - AGRICULTURAL CEA & GLOBAL MULTI-SECTOR MASTER SUITE
======================================================================
Inventor: Thomas G. Coleman

Included Files:
1. Cool_Power_Core_Agri_and_Master_Summary.pdf  - Print-ready specification, vector schematic & 14-sector master summary
2. Cool_Power_Core_Agri_and_Master_Matrix.xlsx  - Interactive Excel model for CEA scaling & cross-sector comparison
3. Cool_Power_Core_Agri_and_14_Sector_Summary.md - Clean Markdown technical documentation
