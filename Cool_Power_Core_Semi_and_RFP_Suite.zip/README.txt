COOL POWER CORE (CPC-SEMI) & MUNICIPAL/INDUSTRIAL UTILITY RFP SUITE
Inventor: Thomas G. Coleman | Date: November 26, 2026
====================================================================
1. Cool_Power_Core_Semi_and_RFP_Package.pdf  - Print-ready specification, schematic & RFP bid package
2. Cool_Power_Core_Semi_and_RFP_Model.xlsx   - Formula-driven semiconductor scaling & energy balance workbook
3. Cool_Power_Core_Semi_and_RFP_Template.md  - Editable Markdown technical model & utility RFP template
