COOL POWER CORE (CPC) - VOLUME XII (#551-#600) & DoD/DIU RAPID PROTOTYPING SUITE
Inventor & Principal Architect: Thomas Gabriel Coleman
USPTO Patent Portfolio: CPC-PAT-2026-001 through 005-CIP (Claims 1-31 | FIGS. 1-11)

Contents:
1. Cool_Power_Core_Vol12_and_DIU_Whitepaper.pdf  - Print-ready DIU OTA Whitepaper & Volume XII Catalog (#551-#600)
2. Cool_Power_Core_Vol12_and_DIU_Whitepaper.xlsx - Filterable Excel workbook with Vol XII cases, DIU KPIs & 12-mo OTA budget
3. Cool_Power_Core_Vol12_and_DIU_Whitepaper.md   - Clean Markdown source document
4. README.txt                                    - Package index
