COOL POWER CORE (CPC) - VOLUME XIII (#601-#650) & 650-APPLICATION UNIFIED MASTER SUITE
Inventor & IP Holder: Thomas Gabriel Coleman
Master USPTO Patent Portfolio: CPC-PAT-2026-001 through CPC-PAT-2026-005-CIP (31 Claims | 11 Figures)

Included Files:
1. Cool_Power_Core_Vol13_and_650_Master_Index.pdf  - Print-ready landscape catalog & 650-case unified index
2. Cool_Power_Core_Vol13_and_650_Master_Index.xlsx - Filterable 3-tab Excel database (Vol XIII + Volume Rollup + Domain Index)
3. Cool_Power_Core_Vol13_and_650_Master_Index.md   - Clean Markdown specification & complete tables
