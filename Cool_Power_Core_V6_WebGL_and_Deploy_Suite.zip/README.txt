COOL POWER CORE(TM): HORIZONS UNBOUND (v6.4) — WEBGL PLANET & V6 DEPLOYMENT SUITE
Inventor & Architect: Thomas Gabriel Coleman (Corona, CA)

Included Files:
1. Cool_Power_Core_Horizons_Playable_Browser_Game.html : 60 FPS WebGL GLSL 3D procedural planet + Sanctuary Dome builder + Fair ETF Dividend terminal + Voice AI Council + Cross-Device Sync
2. deploy_v6.js                                      : Hardhat multi-chain deployment & verification script (Base 8453 & Robinhood Chain 46630)
3. DeployV6.s.sol                                    : Foundry (forge script) Solidity deployment script
4. Cool_Power_Core_V6_WebGL_and_Deploy_Guide.md      : Deployment & shader architecture guide

Verified Treasury & Patronage Endpoints:
- Investment Gnosis Safe : 0xB386f10EAd67f6cDd7Ee8662c8749354E8B48b37
- Direct EVM Patronage   : 0x1419734ee0d1e213f4496d6bf088cc3b480ccedf
- Donate BTC / Sats      : howeyecrypto@cake.cash
- Donate Solana (SOL)    : 2eRUANUAcvyWw1fyHnBSS53g4pWURXcE4se1WRW6H3Nr
