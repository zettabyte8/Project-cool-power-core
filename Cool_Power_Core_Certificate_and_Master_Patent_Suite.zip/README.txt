COOL POWER CORE (CPC) — COMMEMORATIVE CERTIFICATE & MASTER PATENT PORTFOLIO SUMMARY
Inventor: Thomas Gabriel Coleman | Location: Corona, CA, USA | Date: November 26, 2026

Included Files:
1. Cool_Power_Core_Certificate_and_Master_Patent_Summary.pdf — Single-page print-ready Certificate of Invention & Master Patent Portfolio Summary (Landscape Letter).
2. Cool_Power_Core_Certificate_and_Master_Patent_Summary.md  — Clean Markdown reference covering the Certificate attestation, all 5 USPTO patent filings (Claims 1–31, FIGS. 1–11), and program benchmarks.
