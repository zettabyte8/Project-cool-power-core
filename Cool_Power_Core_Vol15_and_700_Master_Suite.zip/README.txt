COOL POWER CORE (CPC) - VOLUME XV (#701-#750) & 700-APPLICATION MASTER INDEX SUITE
Inventor & Principal Architect: Thomas Gabriel Coleman
USPTO Master Docket: CPC-PAT-2026-001 through CPC-PAT-2026-005-CIP (Claims 1-31 | FIGS. 1-11)

Contents:
1. Cool_Power_Core_Vol15_and_700_Master_Index.pdf  - Print-ready landscape catalog & unified 700-case master index
2. Cool_Power_Core_Vol15_and_700_Master_Index.xlsx - Filterable 3-tab Excel workbook (Vol XV, Master 700, Domain Rollup)
3. Cool_Power_Core_Vol15_and_700_Master_Index.md   - Clean Markdown technical reference
